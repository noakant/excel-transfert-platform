/*
  # Système de stockage de fichiers Excel

  1. Nouvelles Tables
    - `uploaded_files` - Métadonnées des fichiers uploadés
    - `file_data` - Données ligne par ligne des fichiers
    - `mappings` - Configurations de mapping sauvegardées
    - `transfer_history` - Historique des transferts

  2. Sécurité
    - Enable RLS sur toutes les tables
    - Politiques pour que chaque utilisateur accède uniquement à ses données

  3. Indexes
    - Optimisation des requêtes sur les colonnes fréquemment utilisées
*/

-- Table pour stocker les métadonnées des fichiers
CREATE TABLE IF NOT EXISTS uploaded_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('source', 'destination')),
  headers jsonb NOT NULL,
  row_count integer DEFAULT 0,
  uploaded_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table pour stocker les données des fichiers ligne par ligne
CREATE TABLE IF NOT EXISTS file_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid REFERENCES uploaded_files(id) ON DELETE CASCADE,
  row_index integer NOT NULL,
  row_data jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Table pour stocker les configurations de mapping
CREATE TABLE IF NOT EXISTS mappings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  source_file_id uuid REFERENCES uploaded_files(id) ON DELETE CASCADE,
  destination_file_id uuid REFERENCES uploaded_files(id) ON DELETE CASCADE,
  mapping_config jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table pour l'historique des transferts
CREATE TABLE IF NOT EXISTS transfer_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  source_file_id uuid REFERENCES uploaded_files(id) ON DELETE CASCADE,
  destination_file_id uuid REFERENCES uploaded_files(id) ON DELETE CASCADE,
  mapping_config jsonb NOT NULL,
  rows_processed integer DEFAULT 0,
  total_rows integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE uploaded_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_history ENABLE ROW LEVEL SECURITY;

-- Politiques RLS pour uploaded_files
CREATE POLICY "Users can manage their own files"
  ON uploaded_files
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Politiques RLS pour file_data
CREATE POLICY "Users can manage their own file data"
  ON file_data
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM uploaded_files 
      WHERE uploaded_files.id = file_data.file_id 
      AND uploaded_files.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM uploaded_files 
      WHERE uploaded_files.id = file_data.file_id 
      AND uploaded_files.user_id = auth.uid()
    )
  );

-- Politiques RLS pour mappings
CREATE POLICY "Users can manage their own mappings"
  ON mappings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Politiques RLS pour transfer_history
CREATE POLICY "Users can manage their own transfer history"
  ON transfer_history
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Indexes pour optimiser les performances
CREATE INDEX IF NOT EXISTS idx_uploaded_files_user_id ON uploaded_files(user_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_files_type ON uploaded_files(type);
CREATE INDEX IF NOT EXISTS idx_file_data_file_id ON file_data(file_id);
CREATE INDEX IF NOT EXISTS idx_file_data_row_index ON file_data(file_id, row_index);
CREATE INDEX IF NOT EXISTS idx_mappings_user_id ON mappings(user_id);
CREATE INDEX IF NOT EXISTS idx_transfer_history_user_id ON transfer_history(user_id);