import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3d9a1eec"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/project/src/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3d9a1eec"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Upload, Download, FileSpreadsheet, ArrowRight, Trash2, RotateCcw, History, AlertCircle, CheckCircle, Info, LogOut, Database } from "/node_modules/lucide-react/dist/esm/lucide-react.js?v=56689416";
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=fba21752";
import { supabase } from "/src/lib/supabase.ts";
import Auth from "/src/components/Auth.tsx";
import { downloadSourceCode } from "/src/utils/downloadSource.ts";
import {
  saveFileToSupabase,
  getFileFromSupabase,
  getUserFiles,
  saveMappingConfig,
  saveToHistory,
  getTransferHistory,
  getSavedMappings,
  deleteMappingConfig
} from "/src/services/fileService.ts";
const App = () => {
  _s();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sourceFile, setSourceFile] = useState(null);
  const [destinationFile, setDestinationFile] = useState(null);
  const [mappings, setMappings] = useState([]);
  const [history, setHistory] = useState([]);
  const [notification, setNotification] = useState(null);
  const [previewData, setPreviewData] = useState([]);
  const [sourceFileId, setSourceFileId] = useState(null);
  const [destinationFileId, setDestinationFileId] = useState(null);
  const [savedFiles, setSavedFiles] = useState([]);
  const [savedMappings, setSavedMappings] = useState([]);
  const [showSaveMappingModal, setShowSaveMappingModal] = useState(false);
  const [mappingName, setMappingName] = useState("");
  React.useEffect(() => {
    const checkAuth = async () => {
      const { data: { user: user2 } } = await supabase.auth.getUser();
      setUser(user2);
      setLoading(false);
      if (user2) {
        loadSavedFiles();
        loadHistory();
        loadSavedMappings();
      }
    };
    checkAuth();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user || null);
      if (session?.user) {
        loadSavedFiles();
        loadHistory();
        loadSavedMappings();
      }
    });
    return () => subscription.unsubscribe();
  }, []);
  const loadSavedFiles = async () => {
    try {
      const files = await getUserFiles();
      setSavedFiles(files);
    } catch (error) {
      console.error("Erreur lors du chargement des fichiers:", error);
    }
  };
  const loadSavedMappings = async () => {
    try {
      const mappings2 = await getSavedMappings();
      setSavedMappings(mappings2);
    } catch (error) {
      console.error("Erreur lors du chargement des mappings:", error);
    }
  };
  const loadHistory = async () => {
    try {
      const historyData = await getTransferHistory();
      const formattedHistory = historyData.map((entry) => ({
        timestamp: new Date(entry.created_at),
        sourceFile: entry.source_file?.name || "Fichier supprimé",
        destinationFile: entry.destination_file?.name || "Fichier supprimé",
        mappings: entry.mapping_config,
        rowsProcessed: entry.rows_processed,
        totalRows: entry.total_rows
      }));
      setHistory(formattedHistory);
    } catch (error) {
      console.error("Erreur lors du chargement de l'historique:", error);
    }
  };
  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSourceFile(null);
    setDestinationFile(null);
    setMappings([]);
    setHistory([]);
    setSavedFiles([]);
    setSavedMappings([]);
  };
  const showNotification = (type, message) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5e3);
  };
  const handleFileUpload = useCallback((event, type) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        setLoading(true);
        const data = new Uint8Array(e.target?.result);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        if (jsonData.length === 0) {
          showNotification("error", "Le fichier est vide");
          return;
        }
        const headers = jsonData[0];
        const rows = jsonData.slice(1);
        const fileData = {
          name: file.name,
          headers,
          data: rows
        };
        const fileId = await saveFileToSupabase(fileData, type);
        if (type === "source") {
          setSourceFile(fileData);
          setSourceFileId(fileId);
          showNotification("success", `Fichier source "${file.name}" chargé avec succès (${rows.length} lignes)`);
        } else {
          setDestinationFile(fileData);
          setDestinationFileId(fileId);
          showNotification("success", `Fichier destination "${file.name}" chargé avec succès (${rows.length} lignes)`);
        }
        loadSavedFiles();
      } catch (error) {
        console.error("Erreur:", error);
        showNotification("error", "Erreur lors de la lecture ou sauvegarde du fichier");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsArrayBuffer(file);
  }, [user]);
  const loadSavedFile = async (fileId, type) => {
    try {
      setLoading(true);
      const fileData = await getFileFromSupabase(fileId);
      if (type === "source") {
        setSourceFile(fileData);
        setSourceFileId(fileId);
      } else {
        setDestinationFile(fileData);
        setDestinationFileId(fileId);
      }
      showNotification("success", `Fichier ${type} "${fileData.name}" chargé depuis la base de données`);
    } catch (error) {
      console.error("Erreur:", error);
      showNotification("error", "Erreur lors du chargement du fichier");
    } finally {
      setLoading(false);
    }
  };
  const addMapping = () => {
    setMappings([...mappings, {
      source: "",
      destination: "",
      transformation: "none",
      replaceRules: [],
      manualValue: ""
    }]);
  };
  const updateMapping = (index, field, value) => {
    const newMappings = [...mappings];
    if (field === "replaceRules") {
      newMappings[index][field] = value;
    } else {
      newMappings[index][field] = value;
    }
    setMappings(newMappings);
  };
  const removeMapping = (index) => {
    setMappings(mappings.filter((_, i) => i !== index));
  };
  const resetMappings = () => {
    setMappings([]);
    showNotification("info", "Mappings réinitialisés");
  };
  const saveMappingConfiguration = async () => {
    if (!sourceFileId || !destinationFileId || mappings.length === 0) {
      showNotification("error", "Veuillez charger les fichiers et définir au moins un mapping");
      return;
    }
    if (!mappingName.trim()) {
      showNotification("error", "Veuillez donner un nom à votre configuration");
      return;
    }
    try {
      await saveMappingConfig(sourceFileId, destinationFileId, mappings, mappingName);
      showNotification("success", `Configuration "${mappingName}" sauvegardée`);
      setShowSaveMappingModal(false);
      setMappingName("");
      loadSavedMappings();
    } catch (error) {
      console.error("Erreur:", error);
      showNotification("error", "Erreur lors de la sauvegarde");
    }
  };
  const loadMappingConfiguration = async (mappingConfig) => {
    try {
      await loadSavedFile(mappingConfig.source_file_id, "source");
      await loadSavedFile(mappingConfig.destination_file_id, "destination");
      const configData = mappingConfig.mapping_config;
      setMappings(configData.mappings || []);
      showNotification("success", `Configuration "${configData.name}" chargée`);
    } catch (error) {
      console.error("Erreur:", error);
      showNotification("error", "Erreur lors du chargement de la configuration");
    }
  };
  const deleteMappingConfiguration = async (mappingId, name) => {
    if (!confirm(`Êtes-vous sûr de vouloir supprimer la configuration "${name}" ?`)) {
      return;
    }
    try {
      await deleteMappingConfig(mappingId);
      showNotification("success", `Configuration "${name}" supprimée`);
      loadSavedMappings();
    } catch (error) {
      console.error("Erreur:", error);
      showNotification("error", "Erreur lors de la suppression");
    }
  };
  const addReplaceRule = (mappingIndex) => {
    const newMappings = [...mappings];
    if (!newMappings[mappingIndex].replaceRules) {
      newMappings[mappingIndex].replaceRules = [];
    }
    newMappings[mappingIndex].replaceRules.push({ from: "", to: "" });
    setMappings(newMappings);
  };
  const updateReplaceRule = (mappingIndex, ruleIndex, field, value) => {
    const newMappings = [...mappings];
    if (newMappings[mappingIndex].replaceRules) {
      newMappings[mappingIndex].replaceRules[ruleIndex][field] = value;
      setMappings(newMappings);
    }
  };
  const removeReplaceRule = (mappingIndex, ruleIndex) => {
    const newMappings = [...mappings];
    if (newMappings[mappingIndex].replaceRules) {
      newMappings[mappingIndex].replaceRules.splice(ruleIndex, 1);
      setMappings(newMappings);
    }
  };
  const applyTransformation = (value, mapping) => {
    if (!value && mapping.transformation !== "manual") return "";
    switch (mapping.transformation) {
      case "uppercase":
        return value.toString().toUpperCase();
      case "lowercase":
        return value.toString().toLowerCase();
      case "replace":
        let result = value.toString();
        mapping.replaceRules?.forEach((rule) => {
          if (rule.from && rule.to !== void 0) {
            const regex = new RegExp(rule.from.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
            result = result.replace(regex, rule.to);
          }
        });
        return result;
      case "manual":
        return mapping.manualValue || "";
      default:
        return value.toString();
    }
  };
  const generatePreview = () => {
    if (!sourceFile || !destinationFile || mappings.length === 0) {
      setPreviewData([]);
      return;
    }
    const previewRows = sourceFile.data.slice(0, 5).map((row) => {
      const newRow = new Array(destinationFile.headers.length).fill("");
      mappings.forEach((mapping) => {
        const destIndex = destinationFile.headers.indexOf(mapping.destination);
        if (destIndex !== -1) {
          if (mapping.transformation === "manual") {
            newRow[destIndex] = applyTransformation("", mapping);
          } else {
            const sourceIndex = sourceFile.headers.indexOf(mapping.source);
            if (sourceIndex !== -1) {
              const sourceValue = row[sourceIndex] || "";
              newRow[destIndex] = applyTransformation(sourceValue, mapping);
            }
          }
        }
      });
      return newRow;
    });
    setPreviewData(previewRows);
  };
  React.useEffect(() => {
    generatePreview();
  }, [mappings, sourceFile, destinationFile]);
  const exportData = () => {
    if (!sourceFile || !destinationFile || mappings.length === 0 || !sourceFileId || !destinationFileId) {
      showNotification("error", "Veuillez charger les fichiers et définir au moins un mapping");
      return;
    }
    const processExport = async () => {
      try {
        setLoading(true);
        const originalDestinationData = [destinationFile.headers, ...destinationFile.data];
        const transformedData = sourceFile.data.map((row) => {
          const newRow = new Array(destinationFile.headers.length).fill("");
          mappings.forEach((mapping) => {
            const destIndex = destinationFile.headers.indexOf(mapping.destination);
            if (destIndex !== -1) {
              if (mapping.transformation === "manual") {
                newRow[destIndex] = applyTransformation("", mapping);
              } else {
                const sourceIndex = sourceFile.headers.indexOf(mapping.source);
                if (sourceIndex !== -1) {
                  const sourceValue = row[sourceIndex] || "";
                  newRow[destIndex] = applyTransformation(sourceValue, mapping);
                }
              }
            }
          });
          return newRow;
        });
        const finalData = [
          ...originalDestinationData,
          // TOUTES les données existantes (en-tête + lignes)
          ...transformedData
          // Nouvelles données transformées
        ];
        console.log("🔍 Données originales destination:", originalDestinationData.length, "lignes");
        console.log("🔍 Nouvelles données à ajouter:", transformedData.length, "lignes");
        console.log("🔍 Total final:", finalData.length, "lignes");
        const newWorkbook = XLSX.utils.book_new();
        const newWorksheet = XLSX.utils.aoa_to_sheet(finalData);
        XLSX.utils.book_append_sheet(newWorkbook, newWorksheet, "Sheet1");
        const fileName = `${destinationFile.name.replace(".xlsx", "")}_updated.xlsx`;
        XLSX.writeFile(newWorkbook, fileName);
        await saveMappingConfig(sourceFileId, destinationFileId, mappings, `Export ${(/* @__PURE__ */ new Date()).toLocaleString()}`);
        await saveToHistory(
          sourceFileId,
          destinationFileId,
          mappings,
          transformedData.length,
          finalData.length - 1
        );
        await loadHistory();
        loadSavedMappings();
        showNotification(
          "success",
          `Export réussi ! ${originalDestinationData.length - 1} lignes conservées + ${transformedData.length} nouvelles lignes = ${finalData.length - 1} lignes au total`
        );
      } catch (error) {
        console.error("Erreur export:", error);
        showNotification("error", "Erreur lors de l'export des données");
      } finally {
        setLoading(false);
      }
    };
    processExport();
  };
  const clearHistory = () => {
    setHistory([]);
    showNotification("info", "Historique effacé");
  };
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV(Database, { className: "w-16 h-16 text-blue-600 mx-auto mb-4 animate-spin" }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 484,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xl text-gray-600", children: "Chargement..." }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 485,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 483,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 482,
      columnNumber: 7
    }, this);
  }
  if (!user) {
    return /* @__PURE__ */ jsxDEV(Auth, { onAuthSuccess: () => setUser(true) }, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 492,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50", children: [
    notification && /* @__PURE__ */ jsxDEV("div", { className: `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg animate-slide-up ${notification.type === "success" ? "bg-green-500 text-white" : notification.type === "error" ? "bg-red-500 text-white" : "bg-blue-500 text-white"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      notification.type === "success" && /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-5 h-5" }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 505,
        columnNumber: 49
      }, this),
      notification.type === "error" && /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-5 h-5" }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 506,
        columnNumber: 47
      }, this),
      notification.type === "info" && /* @__PURE__ */ jsxDEV(Info, { className: "w-5 h-5" }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 507,
        columnNumber: 46
      }, this),
      notification.message
    ] }, void 0, true, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 504,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 499,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 py-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-8 animate-fade-in", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(FileSpreadsheet, { className: "w-12 h-12 text-blue-600" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 518,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent", children: "Plateforme de Transfert Excel" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 519,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: downloadSourceCode,
              className: "ml-4 flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 526,
                  columnNumber: 17
                }, this),
                "Code Source"
              ]
            },
            void 0,
            true,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 522,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleLogout,
              className: "ml-8 flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 533,
                  columnNumber: 17
                }, this),
                "Déconnexion"
              ]
            },
            void 0,
            true,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 529,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 517,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 516,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl text-gray-600 max-w-2xl mx-auto", children: "Transférez facilement vos données entre fichiers Excel avec stockage sécurisé dans Supabase" }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 538,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 515,
        columnNumber: 9
      }, this),
      savedFiles.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-6 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 mb-4 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Database, { className: "w-6 h-6 text-green-600" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 547,
            columnNumber: 15
          }, this),
          "Fichiers sauvegardés (",
          savedFiles.length,
          ")"
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 546,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-blue-800 mb-2", children: "Fichiers Source" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 552,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: savedFiles.filter((f) => f.type === "source").map(
              (file) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => loadSavedFile(file.id, "source"),
                  className: "w-full text-left p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-blue-800", children: file.name }, void 0, false, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 560,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-blue-600", children: [
                      file.row_count,
                      " lignes • ",
                      new Date(file.uploaded_at).toLocaleDateString()
                    ] }, void 0, true, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 561,
                      columnNumber: 23
                    }, this)
                  ]
                },
                file.id,
                true,
                {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 555,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 553,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 551,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-cyan-800 mb-2", children: "Fichiers Destination" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 567,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: savedFiles.filter((f) => f.type === "destination").map(
              (file) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => loadSavedFile(file.id, "destination"),
                  className: "w-full text-left p-3 bg-cyan-50 rounded-lg hover:bg-cyan-100 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-cyan-800", children: file.name }, void 0, false, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 575,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-cyan-600", children: [
                      file.row_count,
                      " lignes • ",
                      new Date(file.uploaded_at).toLocaleDateString()
                    ] }, void 0, true, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 576,
                      columnNumber: 23
                    }, this)
                  ]
                },
                file.id,
                true,
                {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 570,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 568,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 566,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 550,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 545,
        columnNumber: 9
      }, this),
      savedMappings.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-6 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 mb-4 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-6 h-6 text-purple-600" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 589,
            columnNumber: 15
          }, this),
          "Configurations de mapping sauvegardées (",
          savedMappings.length,
          ")"
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 588,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4", children: savedMappings.map(
          (config) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-purple-50 rounded-lg border border-purple-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-purple-800", children: config.mapping_config.name || "Configuration sans nom" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 597,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-purple-600", children: [
                config.source_file?.name,
                " → ",
                config.destination_file?.name
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 600,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-purple-500", children: [
                config.mapping_config.mappings?.length || 0,
                " mappings • ",
                new Date(config.updated_at).toLocaleString()
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 603,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 596,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => loadMappingConfiguration(config),
                  className: "px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm",
                  children: "Charger"
                },
                void 0,
                false,
                {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 608,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => deleteMappingConfiguration(config.id, config.mapping_config.name),
                  className: "px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm",
                  children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 618,
                    columnNumber: 25
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 614,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 607,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 595,
            columnNumber: 19
          }, this) }, config.id, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 594,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 592,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 587,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 gap-8 mb-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-8 border border-gray-100 animate-scale-in", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
            /* @__PURE__ */ jsxDEV(Upload, { className: "w-8 h-8 text-blue-600" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 633,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Fichier Source" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 634,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 632,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-2 border-dashed border-blue-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                accept: ".xlsx,.xls",
                onChange: (e) => handleFileUpload(e, "source"),
                className: "hidden",
                id: "source-upload"
              },
              void 0,
              false,
              {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 638,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "source-upload", className: "cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV(FileSpreadsheet, { className: "w-16 h-16 text-blue-400 mx-auto mb-4" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 646,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-medium text-gray-700 mb-2", children: sourceFile ? `✅ ${sourceFile.name}` : "Cliquez pour sélectionner le fichier source" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 647,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: sourceFile ? `${sourceFile.data.length} lignes, ${sourceFile.headers.length} colonnes • Sauvegardé dans Supabase` : "Formats supportés: .xlsx, .xls" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 650,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 645,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 637,
            columnNumber: 13
          }, this),
          sourceFile && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 p-4 bg-blue-50 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-blue-800 mb-2", children: "Colonnes disponibles:" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 658,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: sourceFile.headers.map(
              (header, index) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm", children: header }, `source-header-${index}`, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 661,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 659,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 657,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 631,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-8 border border-gray-100 animate-scale-in", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
            /* @__PURE__ */ jsxDEV(Download, { className: "w-8 h-8 text-cyan-600" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 673,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Fichier Destination" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 674,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 672,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-2 border-dashed border-cyan-300 rounded-xl p-8 text-center hover:border-cyan-400 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                accept: ".xlsx,.xls",
                onChange: (e) => handleFileUpload(e, "destination"),
                className: "hidden",
                id: "destination-upload"
              },
              void 0,
              false,
              {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 678,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "destination-upload", className: "cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV(FileSpreadsheet, { className: "w-16 h-16 text-cyan-400 mx-auto mb-4" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 686,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-medium text-gray-700 mb-2", children: destinationFile ? `✅ ${destinationFile.name}` : "Cliquez pour sélectionner le fichier destination" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 687,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: destinationFile ? `${destinationFile.data.length} lignes, ${destinationFile.headers.length} colonnes • Sauvegardé dans Supabase` : "Formats supportés: .xlsx, .xls" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 690,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 685,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 677,
            columnNumber: 13
          }, this),
          destinationFile && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 p-4 bg-cyan-50 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-cyan-800 mb-2", children: "Colonnes disponibles:" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 698,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: destinationFile.headers.map(
              (header, index) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm", children: header }, `dest-header-${index}`, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 701,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 699,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 697,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 671,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 629,
        columnNumber: 9
      }, this),
      sourceFile && destinationFile && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-8 border border-gray-100 mb-8 animate-slide-up", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-8 h-8 text-purple-600" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 716,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Mapping des Colonnes" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 717,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 715,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowSaveMappingModal(true),
                disabled: mappings.length === 0,
                className: "flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                children: [
                  /* @__PURE__ */ jsxDEV(Database, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 725,
                    columnNumber: 19
                  }, this),
                  "Sauvegarder"
                ]
              },
              void 0,
              true,
              {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 720,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: resetMappings,
                className: "flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors",
                children: [
                  /* @__PURE__ */ jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 732,
                    columnNumber: 19
                  }, this),
                  "Réinitialiser"
                ]
              },
              void 0,
              true,
              {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 728,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: addMapping,
                className: "flex items-center gap-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors",
                children: [
                  /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 739,
                    columnNumber: 19
                  }, this),
                  "Ajouter Mapping"
                ]
              },
              void 0,
              true,
              {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 735,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 719,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 714,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          mappings.map(
            (mapping, index) => /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-lg border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-4", children: [
                mapping.transformation !== "manual" && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Colonne Source" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 751,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      value: mapping.source,
                      onChange: (e) => updateMapping(index, "source", e.target.value),
                      className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent",
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Sélectionner une colonne source" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 757,
                          columnNumber: 27
                        }, this),
                        sourceFile.headers.map(
                          (header, headerIndex) => /* @__PURE__ */ jsxDEV("option", { value: header, children: header }, `source-${headerIndex}`, false, {
                            fileName: "/home/project/src/App.tsx",
                            lineNumber: 759,
                            columnNumber: 21
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 752,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 750,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Colonne Destination" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 766,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      value: mapping.destination,
                      onChange: (e) => updateMapping(index, "destination", e.target.value),
                      className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent",
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Sélectionner une colonne destination" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 772,
                          columnNumber: 25
                        }, this),
                        destinationFile.headers.map(
                          (header, headerIndex) => /* @__PURE__ */ jsxDEV("option", { value: header, children: header }, `dest-${headerIndex}`, false, {
                            fileName: "/home/project/src/App.tsx",
                            lineNumber: 774,
                            columnNumber: 21
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 767,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 765,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Transformation" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 780,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      value: mapping.transformation,
                      onChange: (e) => updateMapping(index, "transformation", e.target.value),
                      className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent",
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "none", children: "Aucune" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 786,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "uppercase", children: "MAJUSCULES" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 787,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "lowercase", children: "minuscules" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 788,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "replace", children: "Remplacer du texte" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 789,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "manual", children: "Valeur manuelle" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 790,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 781,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 779,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 748,
                columnNumber: 19
              }, this),
              mapping.transformation === "replace" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 p-4 bg-blue-50 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "font-medium text-blue-800", children: "Règles de remplacement" }, void 0, false, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 799,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => addReplaceRule(index),
                      className: "px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700",
                      children: "+ Ajouter règle"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 800,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 798,
                  columnNumber: 23
                }, this),
                mapping.replaceRules?.map(
                  (rule, ruleIndex) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        placeholder: "Si contient...",
                        value: rule.from,
                        onChange: (e) => updateReplaceRule(index, ruleIndex, "from", e.target.value),
                        className: "flex-1 p-2 border border-gray-300 rounded"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/home/project/src/App.tsx",
                        lineNumber: 809,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 816,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        placeholder: "Remplacer par...",
                        value: rule.to,
                        onChange: (e) => updateReplaceRule(index, ruleIndex, "to", e.target.value),
                        className: "flex-1 p-2 border border-gray-300 rounded"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/home/project/src/App.tsx",
                        lineNumber: 817,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => removeReplaceRule(index, ruleIndex),
                        className: "p-2 text-red-600 hover:bg-red-50 rounded",
                        children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                          fileName: "/home/project/src/App.tsx",
                          lineNumber: 828,
                          columnNumber: 29
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/home/project/src/App.tsx",
                        lineNumber: 824,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, `rule-${ruleIndex}`, true, {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 808,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 797,
                columnNumber: 15
              }, this),
              mapping.transformation === "manual" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Valeur à insérer" }, void 0, false, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 838,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Tapez la valeur à insérer dans toutes les lignes...",
                    value: mapping.manualValue || "",
                    onChange: (e) => updateMapping(index, "manualValue", e.target.value),
                    className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/home/project/src/App.tsx",
                    lineNumber: 839,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 837,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-4", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => removeMapping(index),
                  className: "flex items-center gap-2 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/home/project/src/App.tsx",
                      lineNumber: 854,
                      columnNumber: 23
                    }, this),
                    "Supprimer ce mapping"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 850,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 849,
                columnNumber: 19
              }, this)
            ] }, `mapping-${index}`, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 747,
              columnNumber: 13
            }, this)
          ),
          mappings.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 text-gray-500", children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-12 h-12 mx-auto mb-4 text-gray-300" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 863,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: 'Aucun mapping défini. Cliquez sur "Ajouter Mapping" pour commencer.' }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 864,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 862,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 745,
          columnNumber: 13
        }, this),
        previewData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-8 p-6 bg-blue-50 rounded-lg border border-blue-200", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-blue-800 mb-4", children: "Prévisualisation (5 premières lignes)" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 872,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-sm", children: [
            /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-blue-100", children: destinationFile.headers.map(
              (header, index) => /* @__PURE__ */ jsxDEV("th", { className: "p-2 text-left text-blue-800 font-medium border border-blue-200", children: header }, `preview-header-${index}`, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 878,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 876,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 875,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { children: previewData.map(
              (row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { className: "bg-white", children: row.map(
                (cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { className: "p-2 border border-blue-200 text-gray-700", children: cell || "-" }, `preview-cell-${rowIndex}-${cellIndex}`, false, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 888,
                  columnNumber: 21
                }, this)
              ) }, `preview-row-${rowIndex}`, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 886,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 884,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 874,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 873,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 871,
          columnNumber: 11
        }, this),
        mappings.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-8 text-center", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: exportData,
            disabled: loading,
            className: "inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all transform hover:scale-105 shadow-lg text-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed",
            children: [
              /* @__PURE__ */ jsxDEV(Download, { className: "w-6 h-6" }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 906,
                columnNumber: 19
              }, this),
              loading ? "Export en cours..." : "Exporter les Données"
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 901,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 900,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 713,
        columnNumber: 9
      }, this),
      showSaveMappingModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl p-8 max-w-md w-full mx-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-800 mb-4", children: "Sauvegarder la configuration" }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 918,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Nom de la configuration" }, void 0, false, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 920,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: mappingName,
              onChange: (e) => setMappingName(e.target.value),
              placeholder: "Ex: Mapping clients vers commandes",
              className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            },
            void 0,
            false,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 923,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 919,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowSaveMappingModal(false);
                setMappingName("");
              },
              className: "flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors",
              children: "Annuler"
            },
            void 0,
            false,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 932,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: saveMappingConfiguration,
              className: "flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors",
              children: "Sauvegarder"
            },
            void 0,
            false,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 941,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 931,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 917,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 916,
        columnNumber: 9
      }, this),
      history.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-8 border border-gray-100 animate-slide-up", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(History, { className: "w-8 h-8 text-green-600" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 957,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Historique des Transferts" }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 958,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 956,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: clearHistory,
              className: "flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/home/project/src/App.tsx",
                  lineNumber: 964,
                  columnNumber: 17
                }, this),
                "Effacer l'historique"
              ]
            },
            void 0,
            true,
            {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 960,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 955,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: history.map(
          (entry, index) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-green-50 rounded-lg border border-green-200", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-green-800", children: [
                "📊 ",
                entry.sourceFile,
                " → ",
                entry.destinationFile
              ] }, void 0, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 973,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-green-600", children: entry.timestamp.toLocaleString() }, void 0, false, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 976,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 972,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-700 mb-2", children: [
              entry.rowsProcessed,
              " lignes traitées • ",
              entry.totalRows,
              " lignes au total • Sauvegardé dans Supabase"
            ] }, void 0, true, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 980,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: entry.mappings.map(
              (mapping, mappingIndex) => /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 bg-green-100 text-green-800 rounded text-xs", children: [
                mapping.source,
                " → ",
                mapping.destination
              ] }, `mapping-${mappingIndex}`, true, {
                fileName: "/home/project/src/App.tsx",
                lineNumber: 985,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/home/project/src/App.tsx",
              lineNumber: 983,
              columnNumber: 19
            }, this)
          ] }, `history-${index}-${entry.timestamp.getTime()}`, true, {
            fileName: "/home/project/src/App.tsx",
            lineNumber: 971,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/home/project/src/App.tsx",
          lineNumber: 969,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 954,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 513,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/project/src/App.tsx",
    lineNumber: 496,
    columnNumber: 5
  }, this);
};
_s(App, "g8uzPfxjercZMfpeJlVktUzCeWM=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/project/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/project/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWVVOzJCQW5lVjtBQUFnQkEsTUFBVUMsY0FBVyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BELFNBQVNDLFFBQVFDLFVBQVVDLGlCQUFpQkMsWUFBWUMsUUFBUUMsV0FBV0MsU0FBU0MsYUFBYUMsYUFBYUMsTUFBTUMsUUFBUUMsZ0JBQWdCO0FBQzVJLFlBQVlDLFVBQVU7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsMEJBQTBCO0FBQ25DO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFFQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQXlCUCxNQUFNQyxNQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJN0IsU0FBYyxJQUFJO0FBQzFDLFFBQU0sQ0FBQzhCLFNBQVNDLFVBQVUsSUFBSS9CLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNnQyxZQUFZQyxhQUFhLElBQUlqQyxTQUEwQixJQUFJO0FBQ2xFLFFBQU0sQ0FBQ2tDLGlCQUFpQkMsa0JBQWtCLElBQUluQyxTQUEwQixJQUFJO0FBQzVFLFFBQU0sQ0FBQ29DLFVBQVVDLFdBQVcsSUFBSXJDLFNBQTBCLEVBQUU7QUFDNUQsUUFBTSxDQUFDc0MsU0FBU0MsVUFBVSxJQUFJdkMsU0FBeUIsRUFBRTtBQUN6RCxRQUFNLENBQUN3QyxjQUFjQyxlQUFlLElBQUl6QyxTQUF5RSxJQUFJO0FBQ3JILFFBQU0sQ0FBQzBDLGFBQWFDLGNBQWMsSUFBSTNDLFNBQWtCLEVBQUU7QUFDMUQsUUFBTSxDQUFDNEMsY0FBY0MsZUFBZSxJQUFJN0MsU0FBd0IsSUFBSTtBQUNwRSxRQUFNLENBQUM4QyxtQkFBbUJDLG9CQUFvQixJQUFJL0MsU0FBd0IsSUFBSTtBQUM5RSxRQUFNLENBQUNnRCxZQUFZQyxhQUFhLElBQUlqRCxTQUFnQixFQUFFO0FBQ3RELFFBQU0sQ0FBQ2tELGVBQWVDLGdCQUFnQixJQUFJbkQsU0FBZ0IsRUFBRTtBQUM1RCxRQUFNLENBQUNvRCxzQkFBc0JDLHVCQUF1QixJQUFJckQsU0FBUyxLQUFLO0FBQ3RFLFFBQU0sQ0FBQ3NELGFBQWFDLGNBQWMsSUFBSXZELFNBQVMsRUFBRTtBQUdqRHdELFFBQU1DLFVBQVUsTUFBTTtBQUNwQixVQUFNQyxZQUFZLFlBQVk7QUFDNUIsWUFBTSxFQUFFQyxNQUFNLEVBQUUvQixZQUFLLEVBQUUsSUFBSSxNQUFNYixTQUFTNkMsS0FBS0MsUUFBUTtBQUN2RGhDLGNBQVFELEtBQUk7QUFDWkcsaUJBQVcsS0FBSztBQUVoQixVQUFJSCxPQUFNO0FBQ1JrQyx1QkFBZTtBQUNmQyxvQkFBWTtBQUNaQywwQkFBa0I7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFFQU4sY0FBVTtBQUdWLFVBQU0sRUFBRUMsTUFBTSxFQUFFTSxhQUFhLEVBQUUsSUFBSWxELFNBQVM2QyxLQUFLTSxrQkFBa0IsQ0FBQ0MsT0FBT0MsWUFBWTtBQUNyRnZDLGNBQVF1QyxTQUFTeEMsUUFBUSxJQUFJO0FBQzdCLFVBQUl3QyxTQUFTeEMsTUFBTTtBQUNqQmtDLHVCQUFlO0FBQ2ZDLG9CQUFZO0FBQ1pDLDBCQUFrQjtBQUFBLE1BQ3BCO0FBQUEsSUFDRixDQUFDO0FBRUQsV0FBTyxNQUFNQyxhQUFhSSxZQUFZO0FBQUEsRUFDeEMsR0FBRyxFQUFFO0FBRUwsUUFBTVAsaUJBQWlCLFlBQVk7QUFDakMsUUFBSTtBQUNGLFlBQU1RLFFBQVEsTUFBTWxELGFBQWE7QUFDakM2QixvQkFBY3FCLEtBQUs7QUFBQSxJQUNyQixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkNBQTJDQSxLQUFLO0FBQUEsSUFDaEU7QUFBQSxFQUNGO0FBRUEsUUFBTVAsb0JBQW9CLFlBQVk7QUFDcEMsUUFBSTtBQUNGLFlBQU01QixZQUFXLE1BQU1aLGlCQUFpQjtBQUN4QzJCLHVCQUFpQmYsU0FBUTtBQUFBLElBQzNCLFNBQVNtQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkNBQTJDQSxLQUFLO0FBQUEsSUFDaEU7QUFBQSxFQUNGO0FBRUEsUUFBTVIsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNVSxjQUFjLE1BQU1sRCxtQkFBbUI7QUFDN0MsWUFBTW1ELG1CQUFtQkQsWUFBWUUsSUFBSSxDQUFDQyxXQUFnQjtBQUFBLFFBQ3hEQyxXQUFXLElBQUlDLEtBQUtGLE1BQU1HLFVBQVU7QUFBQSxRQUNwQy9DLFlBQVk0QyxNQUFNSSxhQUFhQyxRQUFRO0FBQUEsUUFDdkMvQyxpQkFBaUIwQyxNQUFNTSxrQkFBa0JELFFBQVE7QUFBQSxRQUNqRDdDLFVBQVV3QyxNQUFNTztBQUFBQSxRQUNoQkMsZUFBZVIsTUFBTVM7QUFBQUEsUUFDckJDLFdBQVdWLE1BQU1XO0FBQUFBLE1BQ25CLEVBQUU7QUFDRmhELGlCQUFXbUMsZ0JBQWdCO0FBQUEsSUFDN0IsU0FBU0gsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDhDQUErQ0EsS0FBSztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLFFBQU1pQixlQUFlLFlBQVk7QUFDL0IsVUFBTXpFLFNBQVM2QyxLQUFLNkIsUUFBUTtBQUM1QjVELFlBQVEsSUFBSTtBQUNaSSxrQkFBYyxJQUFJO0FBQ2xCRSx1QkFBbUIsSUFBSTtBQUN2QkUsZ0JBQVksRUFBRTtBQUNkRSxlQUFXLEVBQUU7QUFDYlUsa0JBQWMsRUFBRTtBQUNoQkUscUJBQWlCLEVBQUU7QUFBQSxFQUNyQjtBQUVBLFFBQU11QyxtQkFBbUJBLENBQUNDLE1BQW9DQyxZQUFvQjtBQUNoRm5ELG9CQUFnQixFQUFFa0QsTUFBTUMsUUFBUSxDQUFDO0FBQ2pDQyxlQUFXLE1BQU1wRCxnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxFQUM5QztBQUVBLFFBQU1xRCxtQkFBbUI3RixZQUFZLENBQUNrRSxPQUE0Q3dCLFNBQW1DO0FBQ25ILFVBQU1JLE9BQU81QixNQUFNNkIsT0FBTzFCLFFBQVEsQ0FBQztBQUNuQyxRQUFJLENBQUN5QixRQUFRLENBQUNuRSxLQUFNO0FBRXBCLFVBQU1xRSxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsT0FBT0MsTUFBTTtBQUMzQixVQUFJO0FBQ0ZyRSxtQkFBVyxJQUFJO0FBQ2YsY0FBTTRCLE9BQU8sSUFBSTBDLFdBQVdELEVBQUVKLFFBQVFNLE1BQXFCO0FBQzNELGNBQU1DLFdBQVd6RixLQUFLMEYsS0FBSzdDLE1BQU0sRUFBRWdDLE1BQU0sUUFBUSxDQUFDO0FBQ2xELGNBQU1jLFlBQVlGLFNBQVNHLFdBQVcsQ0FBQztBQUN2QyxjQUFNQyxZQUFZSixTQUFTSyxPQUFPSCxTQUFTO0FBQzNDLGNBQU1JLFdBQVcvRixLQUFLZ0csTUFBTUMsY0FBY0osV0FBVyxFQUFFSyxRQUFRLEVBQUUsQ0FBQztBQUVsRSxZQUFJSCxTQUFTSSxXQUFXLEdBQUc7QUFDekJ2QiwyQkFBaUIsU0FBUyxxQkFBcUI7QUFDL0M7QUFBQSxRQUNGO0FBRUEsY0FBTXdCLFVBQVVMLFNBQVMsQ0FBQztBQUMxQixjQUFNTSxPQUFPTixTQUFTTyxNQUFNLENBQUM7QUFFN0IsY0FBTUMsV0FBcUI7QUFBQSxVQUN6QnBDLE1BQU1jLEtBQUtkO0FBQUFBLFVBQ1hpQztBQUFBQSxVQUNBdkQsTUFBTXdEO0FBQUFBLFFBQ1I7QUFHQSxjQUFNRyxTQUFTLE1BQU1wRyxtQkFBbUJtRyxVQUFVMUIsSUFBSTtBQUV0RCxZQUFJQSxTQUFTLFVBQVU7QUFDckIxRCx3QkFBY29GLFFBQVE7QUFDdEJ4RSwwQkFBZ0J5RSxNQUFNO0FBQ3RCNUIsMkJBQWlCLFdBQVcsbUJBQW1CSyxLQUFLZCxJQUFJLHlCQUF5QmtDLEtBQUtGLE1BQU0sVUFBVTtBQUFBLFFBQ3hHLE9BQU87QUFDTDlFLDZCQUFtQmtGLFFBQVE7QUFDM0J0RSwrQkFBcUJ1RSxNQUFNO0FBQzNCNUIsMkJBQWlCLFdBQVcsd0JBQXdCSyxLQUFLZCxJQUFJLHlCQUF5QmtDLEtBQUtGLE1BQU0sVUFBVTtBQUFBLFFBQzdHO0FBR0FuRCx1QkFBZTtBQUFBLE1BQ2pCLFNBQVNTLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sV0FBV0EsS0FBSztBQUM5Qm1CLHlCQUFpQixTQUFTLG9EQUFvRDtBQUFBLE1BQ2hGLFVBQUM7QUFDQzNELG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFDQWtFLFdBQU9zQixrQkFBa0J4QixJQUFJO0FBQUEsRUFDL0IsR0FBRyxDQUFDbkUsSUFBSSxDQUFDO0FBRVQsUUFBTTRGLGdCQUFnQixPQUFPRixRQUFnQjNCLFNBQW1DO0FBQzlFLFFBQUk7QUFDRjVELGlCQUFXLElBQUk7QUFDZixZQUFNc0YsV0FBVyxNQUFNbEcsb0JBQW9CbUcsTUFBTTtBQUVqRCxVQUFJM0IsU0FBUyxVQUFVO0FBQ3JCMUQsc0JBQWNvRixRQUFRO0FBQ3RCeEUsd0JBQWdCeUUsTUFBTTtBQUFBLE1BQ3hCLE9BQU87QUFDTG5GLDJCQUFtQmtGLFFBQVE7QUFDM0J0RSw2QkFBcUJ1RSxNQUFNO0FBQUEsTUFDN0I7QUFFQTVCLHVCQUFpQixXQUFXLFdBQVdDLElBQUksS0FBSzBCLFNBQVNwQyxJQUFJLG9DQUFvQztBQUFBLElBQ25HLFNBQVNWLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxXQUFXQSxLQUFLO0FBQzlCbUIsdUJBQWlCLFNBQVMsc0NBQXNDO0FBQUEsSUFDbEUsVUFBQztBQUNDM0QsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU0wRixhQUFhQSxNQUFNO0FBQ3ZCcEYsZ0JBQVksQ0FBQyxHQUFHRCxVQUFVO0FBQUEsTUFDeEJzRixRQUFRO0FBQUEsTUFDUkMsYUFBYTtBQUFBLE1BQ2JDLGdCQUFnQjtBQUFBLE1BQ2hCQyxjQUFjO0FBQUEsTUFDZEMsYUFBYTtBQUFBLElBQ2YsQ0FBQyxDQUFDO0FBQUEsRUFDSjtBQUVBLFFBQU1DLGdCQUFnQkEsQ0FBQ0MsT0FBZUMsT0FBNEJDLFVBQWU7QUFDL0UsVUFBTUMsY0FBYyxDQUFDLEdBQUcvRixRQUFRO0FBQ2hDLFFBQUk2RixVQUFVLGdCQUFnQjtBQUM1QkUsa0JBQVlILEtBQUssRUFBRUMsS0FBSyxJQUFJQztBQUFBQSxJQUM5QixPQUFPO0FBQ0wsTUFBQ0MsWUFBWUgsS0FBSyxFQUFVQyxLQUFLLElBQUlDO0FBQUFBLElBQ3ZDO0FBQ0E3RixnQkFBWThGLFdBQVc7QUFBQSxFQUN6QjtBQUVBLFFBQU1DLGdCQUFnQkEsQ0FBQ0osVUFBa0I7QUFDdkMzRixnQkFBWUQsU0FBU2lHLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUEsTUFBTVAsS0FBSyxDQUFDO0FBQUEsRUFDcEQ7QUFFQSxRQUFNUSxnQkFBZ0JBLE1BQU07QUFDMUJuRyxnQkFBWSxFQUFFO0FBQ2RxRCxxQkFBaUIsUUFBUSx3QkFBd0I7QUFBQSxFQUNuRDtBQUVBLFFBQU0rQywyQkFBMkIsWUFBWTtBQUMzQyxRQUFJLENBQUM3RixnQkFBZ0IsQ0FBQ0UscUJBQXFCVixTQUFTNkUsV0FBVyxHQUFHO0FBQ2hFdkIsdUJBQWlCLFNBQVMsOERBQThEO0FBQ3hGO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ3BDLFlBQVlvRixLQUFLLEdBQUc7QUFDdkJoRCx1QkFBaUIsU0FBUyw4Q0FBOEM7QUFDeEU7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGLFlBQU1yRSxrQkFBa0J1QixjQUFjRSxtQkFBbUJWLFVBQVVrQixXQUFXO0FBQzlFb0MsdUJBQWlCLFdBQVcsa0JBQWtCcEMsV0FBVyxlQUFlO0FBQ3hFRCw4QkFBd0IsS0FBSztBQUM3QkUscUJBQWUsRUFBRTtBQUNqQlMsd0JBQWtCO0FBQUEsSUFDcEIsU0FBU08sT0FBTztBQUNkQyxjQUFRRCxNQUFNLFdBQVdBLEtBQUs7QUFDOUJtQix1QkFBaUIsU0FBUyw4QkFBOEI7QUFBQSxJQUMxRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUQsMkJBQTJCLE9BQU9DLGtCQUF1QjtBQUM3RCxRQUFJO0FBRUYsWUFBTXBCLGNBQWNvQixjQUFjQyxnQkFBZ0IsUUFBUTtBQUMxRCxZQUFNckIsY0FBY29CLGNBQWNFLHFCQUFxQixhQUFhO0FBR3BFLFlBQU1DLGFBQWFILGNBQWN6RDtBQUNqQzlDLGtCQUFZMEcsV0FBVzNHLFlBQVksRUFBRTtBQUVyQ3NELHVCQUFpQixXQUFXLGtCQUFrQnFELFdBQVc5RCxJQUFJLFdBQVc7QUFBQSxJQUMxRSxTQUFTVixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sV0FBV0EsS0FBSztBQUM5Qm1CLHVCQUFpQixTQUFTLCtDQUErQztBQUFBLElBQzNFO0FBQUEsRUFDRjtBQUVBLFFBQU1zRCw2QkFBNkIsT0FBT0MsV0FBbUJoRSxTQUFpQjtBQUM1RSxRQUFJLENBQUNpRSxRQUFRLHdEQUF3RGpFLElBQUksS0FBSyxHQUFHO0FBQy9FO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNeEQsb0JBQW9Cd0gsU0FBUztBQUNuQ3ZELHVCQUFpQixXQUFXLGtCQUFrQlQsSUFBSSxhQUFhO0FBQy9EakIsd0JBQWtCO0FBQUEsSUFDcEIsU0FBU08sT0FBTztBQUNkQyxjQUFRRCxNQUFNLFdBQVdBLEtBQUs7QUFDOUJtQix1QkFBaUIsU0FBUywrQkFBK0I7QUFBQSxJQUMzRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUQsaUJBQWlCQSxDQUFDQyxpQkFBeUI7QUFDL0MsVUFBTWpCLGNBQWMsQ0FBQyxHQUFHL0YsUUFBUTtBQUNoQyxRQUFJLENBQUMrRixZQUFZaUIsWUFBWSxFQUFFdkIsY0FBYztBQUMzQ00sa0JBQVlpQixZQUFZLEVBQUV2QixlQUFlO0FBQUEsSUFDM0M7QUFDQU0sZ0JBQVlpQixZQUFZLEVBQUV2QixhQUFjd0IsS0FBSyxFQUFFQyxNQUFNLElBQUlDLElBQUksR0FBRyxDQUFDO0FBQ2pFbEgsZ0JBQVk4RixXQUFXO0FBQUEsRUFDekI7QUFFQSxRQUFNcUIsb0JBQW9CQSxDQUFDSixjQUFzQkssV0FBbUJ4QixPQUFzQkMsVUFBa0I7QUFDMUcsVUFBTUMsY0FBYyxDQUFDLEdBQUcvRixRQUFRO0FBQ2hDLFFBQUkrRixZQUFZaUIsWUFBWSxFQUFFdkIsY0FBYztBQUMxQ00sa0JBQVlpQixZQUFZLEVBQUV2QixhQUFjNEIsU0FBUyxFQUFFeEIsS0FBSyxJQUFJQztBQUM1RDdGLGtCQUFZOEYsV0FBVztBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFFBQU11QixvQkFBb0JBLENBQUNOLGNBQXNCSyxjQUFzQjtBQUNyRSxVQUFNdEIsY0FBYyxDQUFDLEdBQUcvRixRQUFRO0FBQ2hDLFFBQUkrRixZQUFZaUIsWUFBWSxFQUFFdkIsY0FBYztBQUMxQ00sa0JBQVlpQixZQUFZLEVBQUV2QixhQUFjOEIsT0FBT0YsV0FBVyxDQUFDO0FBQzNEcEgsa0JBQVk4RixXQUFXO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBR0EsUUFBTXlCLHNCQUFzQkEsQ0FBQzFCLE9BQWUyQixZQUFtQztBQUM3RSxRQUFJLENBQUMzQixTQUFTMkIsUUFBUWpDLG1CQUFtQixTQUFVLFFBQU87QUFFMUQsWUFBUWlDLFFBQVFqQyxnQkFBYztBQUFBLE1BQzVCLEtBQUs7QUFDSCxlQUFPTSxNQUFNNEIsU0FBUyxFQUFFQyxZQUFZO0FBQUEsTUFDdEMsS0FBSztBQUNILGVBQU83QixNQUFNNEIsU0FBUyxFQUFFRSxZQUFZO0FBQUEsTUFDdEMsS0FBSztBQUNILFlBQUkxRCxTQUFTNEIsTUFBTTRCLFNBQVM7QUFDNUJELGdCQUFRaEMsY0FBY29DLFFBQVEsQ0FBQUMsU0FBUTtBQUNwQyxjQUFJQSxLQUFLWixRQUFRWSxLQUFLWCxPQUFPWSxRQUFXO0FBQ3RDLGtCQUFNQyxRQUFRLElBQUlDLE9BQU9ILEtBQUtaLEtBQUtnQixRQUFRLHVCQUF1QixNQUFNLEdBQUcsSUFBSTtBQUMvRWhFLHFCQUFTQSxPQUFPZ0UsUUFBUUYsT0FBT0YsS0FBS1gsRUFBRTtBQUFBLFVBQ3hDO0FBQUEsUUFDRixDQUFDO0FBQ0QsZUFBT2pEO0FBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU91RCxRQUFRL0IsZUFBZTtBQUFBLE1BQ2hDO0FBQ0UsZUFBT0ksTUFBTTRCLFNBQVM7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNUyxrQkFBa0JBLE1BQU07QUFDNUIsUUFBSSxDQUFDdkksY0FBYyxDQUFDRSxtQkFBbUJFLFNBQVM2RSxXQUFXLEdBQUc7QUFDNUR0RSxxQkFBZSxFQUFFO0FBQ2pCO0FBQUEsSUFDRjtBQUdBLFVBQU02SCxjQUFjeEksV0FBVzJCLEtBQUt5RCxNQUFNLEdBQUcsQ0FBQyxFQUFFekMsSUFBSSxDQUFBOEYsUUFBTztBQUN6RCxZQUFNQyxTQUFTLElBQUlDLE1BQU16SSxnQkFBZ0JnRixRQUFRRCxNQUFNLEVBQUUyRCxLQUFLLEVBQUU7QUFFaEV4SSxlQUFTNkgsUUFBUSxDQUFBSixZQUFXO0FBQzFCLGNBQU1nQixZQUFZM0ksZ0JBQWdCZ0YsUUFBUTRELFFBQVFqQixRQUFRbEMsV0FBVztBQUVyRSxZQUFJa0QsY0FBYyxJQUFJO0FBQ3BCLGNBQUloQixRQUFRakMsbUJBQW1CLFVBQVU7QUFFdkM4QyxtQkFBT0csU0FBUyxJQUFJakIsb0JBQW9CLElBQUlDLE9BQU87QUFBQSxVQUNyRCxPQUFPO0FBRUwsa0JBQU1rQixjQUFjL0ksV0FBV2tGLFFBQVE0RCxRQUFRakIsUUFBUW5DLE1BQU07QUFDN0QsZ0JBQUlxRCxnQkFBZ0IsSUFBSTtBQUN0QixvQkFBTUMsY0FBY1AsSUFBSU0sV0FBVyxLQUFLO0FBQ3hDTCxxQkFBT0csU0FBUyxJQUFJakIsb0JBQW9Cb0IsYUFBYW5CLE9BQU87QUFBQSxZQUM5RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsYUFBT2E7QUFBQUEsSUFDVCxDQUFDO0FBRUQvSCxtQkFBZTZILFdBQVc7QUFBQSxFQUM1QjtBQUdBaEgsUUFBTUMsVUFBVSxNQUFNO0FBQ3BCOEcsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxDQUFDbkksVUFBVUosWUFBWUUsZUFBZSxDQUFDO0FBRTFDLFFBQU0rSSxhQUFhQSxNQUFNO0FBQ3ZCLFFBQUksQ0FBQ2pKLGNBQWMsQ0FBQ0UsbUJBQW1CRSxTQUFTNkUsV0FBVyxLQUFLLENBQUNyRSxnQkFBZ0IsQ0FBQ0UsbUJBQW1CO0FBQ25HNEMsdUJBQWlCLFNBQVMsOERBQThEO0FBQ3hGO0FBQUEsSUFDRjtBQUVBLFVBQU13RixnQkFBZ0IsWUFBWTtBQUNoQyxVQUFJO0FBQ0ZuSixtQkFBVyxJQUFJO0FBRWYsY0FBTW9KLDBCQUEwQixDQUFDakosZ0JBQWdCZ0YsU0FBUyxHQUFHaEYsZ0JBQWdCeUIsSUFBSTtBQUdqRixjQUFNeUgsa0JBQWtCcEosV0FBVzJCLEtBQUtnQixJQUFJLENBQUE4RixRQUFPO0FBQ2pELGdCQUFNQyxTQUFTLElBQUlDLE1BQU16SSxnQkFBZ0JnRixRQUFRRCxNQUFNLEVBQUUyRCxLQUFLLEVBQUU7QUFFaEV4SSxtQkFBUzZILFFBQVEsQ0FBQUosWUFBVztBQUMxQixrQkFBTWdCLFlBQVkzSSxnQkFBZ0JnRixRQUFRNEQsUUFBUWpCLFFBQVFsQyxXQUFXO0FBRXJFLGdCQUFJa0QsY0FBYyxJQUFJO0FBQ3BCLGtCQUFJaEIsUUFBUWpDLG1CQUFtQixVQUFVO0FBRXZDOEMsdUJBQU9HLFNBQVMsSUFBSWpCLG9CQUFvQixJQUFJQyxPQUFPO0FBQUEsY0FDckQsT0FBTztBQUVMLHNCQUFNa0IsY0FBYy9JLFdBQVdrRixRQUFRNEQsUUFBUWpCLFFBQVFuQyxNQUFNO0FBQzdELG9CQUFJcUQsZ0JBQWdCLElBQUk7QUFDdEIsd0JBQU1DLGNBQWNQLElBQUlNLFdBQVcsS0FBSztBQUN4Q0wseUJBQU9HLFNBQVMsSUFBSWpCLG9CQUFvQm9CLGFBQWFuQixPQUFPO0FBQUEsZ0JBQzlEO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFFRCxpQkFBT2E7QUFBQUEsUUFDVCxDQUFDO0FBR0QsY0FBTVcsWUFBWTtBQUFBLFVBQ2hCLEdBQUdGO0FBQUFBO0FBQUFBLFVBQ0gsR0FBR0M7QUFBQUE7QUFBQUEsUUFBMEI7QUFHL0I1RyxnQkFBUThHLElBQUksc0NBQXNDSCx3QkFBd0JsRSxRQUFRLFFBQVE7QUFDMUZ6QyxnQkFBUThHLElBQUksbUNBQW1DRixnQkFBZ0JuRSxRQUFRLFFBQVE7QUFDL0V6QyxnQkFBUThHLElBQUksbUJBQW1CRCxVQUFVcEUsUUFBUSxRQUFRO0FBR3pELGNBQU1zRSxjQUFjekssS0FBS2dHLE1BQU0wRSxTQUFTO0FBQ3hDLGNBQU1DLGVBQWUzSyxLQUFLZ0csTUFBTTRFLGFBQWFMLFNBQVM7QUFDdER2SyxhQUFLZ0csTUFBTTZFLGtCQUFrQkosYUFBYUUsY0FBYyxRQUFRO0FBR2hFLGNBQU1HLFdBQVcsR0FBRzFKLGdCQUFnQitDLEtBQUtxRixRQUFRLFNBQVMsRUFBRSxDQUFDO0FBQzdEeEosYUFBSytLLFVBQVVOLGFBQWFLLFFBQVE7QUFHcEMsY0FBTXZLLGtCQUFrQnVCLGNBQWNFLG1CQUFtQlYsVUFBVSxXQUFVLG9CQUFJMEMsS0FBSyxHQUFFZ0gsZUFBZSxDQUFDLEVBQUU7QUFHMUcsY0FBTXhLO0FBQUFBLFVBQ0pzQjtBQUFBQSxVQUNBRTtBQUFBQSxVQUNBVjtBQUFBQSxVQUNBZ0osZ0JBQWdCbkU7QUFBQUEsVUFDaEJvRSxVQUFVcEUsU0FBUztBQUFBLFFBQ3JCO0FBR0EsY0FBTWxELFlBQVk7QUFDbEJDLDBCQUFrQjtBQUVsQjBCO0FBQUFBLFVBQWlCO0FBQUEsVUFDZixtQkFBbUJ5Rix3QkFBd0JsRSxTQUFTLENBQUMsd0JBQXdCbUUsZ0JBQWdCbkUsTUFBTSx1QkFBdUJvRSxVQUFVcEUsU0FBUyxDQUFDO0FBQUEsUUFDaEo7QUFBQSxNQUVGLFNBQVMxQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGtCQUFrQkEsS0FBSztBQUNyQ21CLHlCQUFpQixTQUFTLHFDQUFzQztBQUFBLE1BQ2xFLFVBQUM7QUFDQzNELG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQW1KLGtCQUFjO0FBQUEsRUFDaEI7QUFFQSxRQUFNYSxlQUFlQSxNQUFNO0FBQ3pCeEosZUFBVyxFQUFFO0FBQ2JtRCxxQkFBaUIsUUFBUSxtQkFBbUI7QUFBQSxFQUM5QztBQUdBLE1BQUk1RCxTQUFTO0FBQ1gsV0FDRSx1QkFBQyxTQUFJLFdBQVUscUdBQ2IsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxZQUFTLFdBQVUsdURBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxNQUN2RSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsU0FGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsRUFFSjtBQUVBLE1BQUksQ0FBQ0YsTUFBTTtBQUNULFdBQU8sdUJBQUMsUUFBSyxlQUFlLE1BQU1DLFFBQVEsSUFBSSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQUEsRUFDbEQ7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvRUFFWlc7QUFBQUEsb0JBQ0MsdUJBQUMsU0FBSSxXQUFXLHNFQUNkQSxhQUFhbUQsU0FBUyxZQUFZLDRCQUNsQ25ELGFBQWFtRCxTQUFTLFVBQVUsMEJBQ2hDLHdCQUF3QixJQUV4QixpQ0FBQyxTQUFJLFdBQVUsMkJBQ1puRDtBQUFBQSxtQkFBYW1ELFNBQVMsYUFBYSx1QkFBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLE1BQ25FbkQsYUFBYW1ELFNBQVMsV0FBVyx1QkFBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLE1BQ2pFbkQsYUFBYW1ELFNBQVMsVUFBVSx1QkFBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pEbkQsYUFBYW9EO0FBQUFBLFNBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLCtCQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtDQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDZjtBQUFBLGlDQUFDLG1CQUFnQixXQUFVLDZCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQ3BELHVCQUFDLFFBQUcsV0FBVSwrRkFBNkYsNkNBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTM0U7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3VFO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUF5QywyR0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BR0N4QyxXQUFXaUUsU0FBUyxLQUNuQix1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsZ0VBQ1o7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUE7QUFBQSxVQUNyQmpFLFdBQVdpRTtBQUFBQSxVQUFPO0FBQUEsYUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9DQUFtQywrQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFJLFdBQVUsYUFDWmpFLHFCQUFXcUYsT0FBTyxDQUFBMkQsTUFBS0EsRUFBRXJHLFNBQVMsUUFBUSxFQUFFaEI7QUFBQUEsY0FBSSxDQUFDb0IsU0FDaEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsU0FBUyxNQUFNeUIsY0FBY3pCLEtBQUtrRyxJQUFJLFFBQVE7QUFBQSxrQkFDOUMsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDZCQUE2QmxHLGVBQUtkLFFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNEO0FBQUEsb0JBQ3RELHVCQUFDLFNBQUksV0FBVSx5QkFBeUJjO0FBQUFBLDJCQUFLbUc7QUFBQUEsc0JBQVU7QUFBQSxzQkFBVyxJQUFJcEgsS0FBS2lCLEtBQUtvRyxXQUFXLEVBQUVDLG1CQUFtQjtBQUFBLHlCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrSDtBQUFBO0FBQUE7QUFBQSxnQkFMN0dyRyxLQUFLa0c7QUFBQUEsZ0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsWUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLG9DQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFLHVCQUFDLFNBQUksV0FBVSxhQUNaakoscUJBQVdxRixPQUFPLENBQUEyRCxNQUFLQSxFQUFFckcsU0FBUyxhQUFhLEVBQUVoQjtBQUFBQSxjQUFJLENBQUNvQixTQUNyRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxTQUFTLE1BQU15QixjQUFjekIsS0FBS2tHLElBQUksYUFBYTtBQUFBLGtCQUNuRCxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsNkJBQTZCbEcsZUFBS2QsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0Q7QUFBQSxvQkFDdEQsdUJBQUMsU0FBSSxXQUFVLHlCQUF5QmM7QUFBQUEsMkJBQUttRztBQUFBQSxzQkFBVTtBQUFBLHNCQUFXLElBQUlwSCxLQUFLaUIsS0FBS29HLFdBQVcsRUFBRUMsbUJBQW1CO0FBQUEseUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtIO0FBQUE7QUFBQTtBQUFBLGdCQUw3R3JHLEtBQUtrRztBQUFBQSxnQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxZQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUNBO0FBQUEsTUFJRC9JLGNBQWMrRCxTQUFTLEtBQ3RCLHVCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxnRUFDWjtBQUFBLGlDQUFDLGNBQVcsV0FBVSw2QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQTtBQUFBLFVBQ04vRCxjQUFjK0Q7QUFBQUEsVUFBTztBQUFBLGFBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ1ovRCx3QkFBY3lCO0FBQUFBLFVBQUksQ0FBQzBILFdBQ2xCLHVCQUFDLFNBQW9CLFdBQVUsd0RBQzdCLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsaUNBQ1hBLGlCQUFPbEgsZUFBZUYsUUFBUSw0QkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLDJCQUNWb0g7QUFBQUEsdUJBQU9ySCxhQUFhQztBQUFBQSxnQkFBSztBQUFBLGdCQUFJb0gsT0FBT25ILGtCQUFrQkQ7QUFBQUEsbUJBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSwyQkFDVm9IO0FBQUFBLHVCQUFPbEgsZUFBZS9DLFVBQVU2RSxVQUFVO0FBQUEsZ0JBQUU7QUFBQSxnQkFBYSxJQUFJbkMsS0FBS3VILE9BQU9DLFVBQVUsRUFBRVIsZUFBZTtBQUFBLG1CQUR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU1uRCx5QkFBeUIwRCxNQUFNO0FBQUEsa0JBQzlDLFdBQVU7QUFBQSxrQkFBNkY7QUFBQTtBQUFBLGdCQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNckQsMkJBQTJCcUQsT0FBT0osSUFBSUksT0FBT2xILGVBQWVGLElBQUk7QUFBQSxrQkFDL0UsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBO0FBQUEsZ0JBSjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBLEtBM0JRb0gsT0FBT0osSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxRQUNELEtBL0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQ0E7QUFBQSxXQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0NBO0FBQUEsTUFJRix1QkFBQyxTQUFJLFdBQVUsbUNBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxVQUFPLFdBQVUsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUEsWUFDekMsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQyw4QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsVUFBVSxDQUFDN0YsTUFBTU4saUJBQWlCTSxHQUFHLFFBQVE7QUFBQSxnQkFDN0MsV0FBVTtBQUFBLGdCQUNWLElBQUc7QUFBQTtBQUFBLGNBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29CO0FBQUEsWUFFcEIsdUJBQUMsV0FBTSxTQUFRLGlCQUFnQixXQUFVLGtCQUN2QztBQUFBLHFDQUFDLG1CQUFnQixXQUFVLDBDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLE9BQUUsV0FBVSwwQ0FDVnBFLHVCQUFhLEtBQUtBLFdBQVdpRCxJQUFJLEtBQUssaURBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVmpELHVCQUFhLEdBQUdBLFdBQVcyQixLQUFLc0QsTUFBTSxZQUFZakYsV0FBV2tGLFFBQVFELE1BQU0seUNBQXlDLG9DQUR2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFQ2pGLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9DQUFtQyxxQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1pBLHFCQUFXa0YsUUFBUXZDO0FBQUFBLGNBQUksQ0FBQ3FDLFFBQVFnQixVQUMvQix1QkFBQyxVQUFvQyxXQUFVLDREQUM1Q2hCLG9CQURRLGlCQUFpQmdCLEtBQUssSUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDhFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsbUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsZUFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsUUFBTztBQUFBLGdCQUNQLFVBQVUsQ0FBQzVCLE1BQU1OLGlCQUFpQk0sR0FBRyxhQUFhO0FBQUEsZ0JBQ2xELFdBQVU7QUFBQSxnQkFDVixJQUFHO0FBQUE7QUFBQSxjQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt5QjtBQUFBLFlBRXpCLHVCQUFDLFdBQU0sU0FBUSxzQkFBcUIsV0FBVSxrQkFDNUM7QUFBQSxxQ0FBQyxtQkFBZ0IsV0FBVSwwQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxjQUNqRSx1QkFBQyxPQUFFLFdBQVUsMENBQ1ZsRSw0QkFBa0IsS0FBS0EsZ0JBQWdCK0MsSUFBSSxLQUFLLHNEQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1YvQyw0QkFBa0IsR0FBR0EsZ0JBQWdCeUIsS0FBS3NELE1BQU0sWUFBWS9FLGdCQUFnQmdGLFFBQVFELE1BQU0seUNBQXlDLG9DQUR0STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFQy9FLG1CQUNDLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxvQ0FBbUMscUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsU0FBSSxXQUFVLHdCQUNaQSwwQkFBZ0JnRixRQUFRdkM7QUFBQUEsY0FBSSxDQUFDcUMsUUFBUWdCLFVBQ3BDLHVCQUFDLFVBQWtDLFdBQVUsNERBQzFDaEIsb0JBRFEsZUFBZWdCLEtBQUssSUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLFdBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxNQUdDaEcsY0FBY0UsbUJBQ2IsdUJBQUMsU0FBSSxXQUFVLG1GQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsY0FBVyxXQUFVLDZCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQy9DLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsb0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTW1CLHdCQUF3QixJQUFJO0FBQUEsZ0JBQzNDLFVBQVVqQixTQUFTNkUsV0FBVztBQUFBLGdCQUM5QixXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTdUI7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU2Y7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNackY7QUFBQUEsbUJBQVN1QztBQUFBQSxZQUFJLENBQUNrRixTQUFTN0IsVUFDdEIsdUJBQUMsU0FBNkIsV0FBVSxvREFDdEM7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOENBQ1o2QjtBQUFBQSx3QkFBUWpDLG1CQUFtQixZQUMxQix1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEU7QUFBQSxrQkFDOUU7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBT2lDLFFBQVFuQztBQUFBQSxzQkFDZixVQUFVLENBQUN0QixNQUFNMkIsY0FBY0MsT0FBTyxVQUFVNUIsRUFBRUosT0FBT2tDLEtBQUs7QUFBQSxzQkFDOUQsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsWUFBTyxPQUFNLElBQUcsK0NBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdEO0FBQUEsd0JBQy9DbEcsV0FBV2tGLFFBQVF2QztBQUFBQSwwQkFBSSxDQUFDcUMsUUFBUXVGLGdCQUMvQix1QkFBQyxZQUFxQyxPQUFPdkYsUUFBU0Esb0JBQXpDLFVBQVV1RixXQUFXLElBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZEO0FBQUEsd0JBQzlEO0FBQUE7QUFBQTtBQUFBLG9CQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxnQkFHRix1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyxtQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUY7QUFBQSxrQkFDbkY7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTzFDLFFBQVFsQztBQUFBQSxzQkFDZixVQUFVLENBQUN2QixNQUFNMkIsY0FBY0MsT0FBTyxlQUFlNUIsRUFBRUosT0FBT2tDLEtBQUs7QUFBQSxzQkFDbkUsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsWUFBTyxPQUFNLElBQUcsb0RBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXFEO0FBQUEsd0JBQ3BEaEcsZ0JBQWdCZ0YsUUFBUXZDO0FBQUFBLDBCQUFJLENBQUNxQyxRQUFRdUYsZ0JBQ3BDLHVCQUFDLFlBQW1DLE9BQU92RixRQUFTQSxvQkFBdkMsUUFBUXVGLFdBQVcsSUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBMkQ7QUFBQSx3QkFDNUQ7QUFBQTtBQUFBO0FBQUEsb0JBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RTtBQUFBLGtCQUM5RTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFPMUMsUUFBUWpDO0FBQUFBLHNCQUNmLFVBQVUsQ0FBQ3hCLE1BQU0yQixjQUFjQyxPQUFPLGtCQUFrQjVCLEVBQUVKLE9BQU9rQyxLQUFLO0FBQUEsc0JBQ3RFLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFlBQU8sT0FBTSxRQUFPLHNCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEyQjtBQUFBLHdCQUMzQix1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0M7QUFBQSx3QkFDcEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9DO0FBQUEsd0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxXQUFVLGtDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEwQztBQUFBLHdCQUMxQyx1QkFBQyxZQUFPLE9BQU0sVUFBUywrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0M7QUFBQTtBQUFBO0FBQUEsb0JBVHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLHFCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxtQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxjQUdDMkIsUUFBUWpDLG1CQUFtQixhQUMxQix1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsNkJBQTRCLHNDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRTtBQUFBLGtCQUNoRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU11QixlQUFlbkIsS0FBSztBQUFBLHNCQUNuQyxXQUFVO0FBQUEsc0JBQW9FO0FBQUE7QUFBQSxvQkFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNDNkIsUUFBUWhDLGNBQWNsRDtBQUFBQSxrQkFBSSxDQUFDdUYsTUFBTVQsY0FDaEMsdUJBQUMsU0FBOEIsV0FBVSxnQ0FDdkM7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsYUFBWTtBQUFBLHdCQUNaLE9BQU9TLEtBQUtaO0FBQUFBLHdCQUNaLFVBQVUsQ0FBQ2xELE1BQU1vRCxrQkFBa0J4QixPQUFPeUIsV0FBVyxRQUFRckQsRUFBRUosT0FBT2tDLEtBQUs7QUFBQSx3QkFDM0UsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUt1RDtBQUFBLG9CQUV2RCx1QkFBQyxjQUFXLFdBQVUsMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsb0JBQzdDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxhQUFZO0FBQUEsd0JBQ1osT0FBT2dDLEtBQUtYO0FBQUFBLHdCQUNaLFVBQVUsQ0FBQ25ELE1BQU1vRCxrQkFBa0J4QixPQUFPeUIsV0FBVyxNQUFNckQsRUFBRUosT0FBT2tDLEtBQUs7QUFBQSx3QkFDekUsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUt1RDtBQUFBLG9CQUV2RDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLE1BQU13QixrQkFBa0IxQixPQUFPeUIsU0FBUztBQUFBLHdCQUNqRCxXQUFVO0FBQUEsd0JBRVYsaUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJCO0FBQUE7QUFBQSxzQkFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsdUJBckJRLFFBQVFBLFNBQVMsSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxnQkFDRDtBQUFBLG1CQWxDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1DQTtBQUFBLGNBSURJLFFBQVFqQyxtQkFBbUIsWUFDMUIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRjtBQUFBLGdCQUNoRjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9pQyxRQUFRL0IsZUFBZTtBQUFBLG9CQUM5QixVQUFVLENBQUMxQixNQUFNMkIsY0FBY0MsT0FBTyxlQUFlNUIsRUFBRUosT0FBT2tDLEtBQUs7QUFBQSxvQkFDbkUsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtzSDtBQUFBLG1CQVB4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FHRix1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNRSxjQUFjSixLQUFLO0FBQUEsa0JBQ2xDLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkE5R1EsV0FBV0EsS0FBSyxJQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStHQTtBQUFBLFVBQ0Q7QUFBQSxVQUVBNUYsU0FBUzZFLFdBQVcsS0FDbkIsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsbUNBQUMsY0FBVyxXQUFVLDBDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RDtBQUFBLFlBQzVELHVCQUFDLE9BQUUsbUZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxlQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUF4SEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBIQTtBQUFBLFFBR0N2RSxZQUFZdUUsU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNENBQTJDLHFEQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLFVBQzlGLHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsa0JBQ2Y7QUFBQSxtQ0FBQyxXQUNDLGlDQUFDLFFBQUcsV0FBVSxlQUNYL0UsMEJBQWdCZ0YsUUFBUXZDO0FBQUFBLGNBQUksQ0FBQ3FDLFFBQVFnQixVQUNwQyx1QkFBQyxRQUFtQyxXQUFVLGtFQUMzQ2hCLG9CQURNLGtCQUFrQmdCLEtBQUssSUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsV0FDRXRGLHNCQUFZaUM7QUFBQUEsY0FBSSxDQUFDOEYsS0FBSytCLGFBQ3JCLHVCQUFDLFFBQW1DLFdBQVUsWUFDM0MvQixjQUFJOUY7QUFBQUEsZ0JBQUksQ0FBQzhILE1BQU1DLGNBQ2QsdUJBQUMsUUFBaUQsV0FBVSw0Q0FDekRELGtCQUFRLE9BREYsZ0JBQWdCRCxRQUFRLElBQUlFLFNBQVMsSUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0QsS0FMTSxlQUFlRixRQUFRLElBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxZQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBLEtBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRURwSyxTQUFTNkUsU0FBUyxLQUNqQix1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNnRTtBQUFBQSxZQUNULFVBQVVuSjtBQUFBQSxZQUNWLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDNUJBLFVBQVUsdUJBQXVCO0FBQUE7QUFBQTtBQUFBLFVBTnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FwTUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNNQTtBQUFBLE1BSURzQix3QkFDQyx1QkFBQyxTQUFJLFdBQVUsOEVBQ2IsaUNBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdDQUF1Qyw0Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUE4Qyx1Q0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9FO0FBQUFBLGNBQ1AsVUFBVSxDQUFDOEMsTUFBTTdDLGVBQWU2QyxFQUFFSixPQUFPa0MsS0FBSztBQUFBLGNBQzlDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FIO0FBQUEsYUFUdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYjdFLHdDQUF3QixLQUFLO0FBQzdCRSwrQkFBZSxFQUFFO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUEyRjtBQUFBO0FBQUEsWUFMdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTa0Y7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBMEY7QUFBQTtBQUFBLFlBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQSxLQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsTUFJRG5HLFFBQVEyRSxTQUFTLEtBQ2hCLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFdBQVEsV0FBVSw0QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxZQUMzQyx1QkFBQyxRQUFHLFdBQVUsb0NBQW1DLHlDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLGVBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTOEU7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNaekosa0JBQVFxQztBQUFBQSxVQUFJLENBQUNDLE9BQU9vRCxVQUNuQix1QkFBQyxTQUEwRCxXQUFVLHNEQUNuRTtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxnQ0FBOEI7QUFBQTtBQUFBLGdCQUN4Q3BELE1BQU01QztBQUFBQSxnQkFBVztBQUFBLGdCQUFJNEMsTUFBTTFDO0FBQUFBLG1CQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsMEJBQ2IwQyxnQkFBTUMsVUFBVWlILGVBQWUsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFDVmxIO0FBQUFBLG9CQUFNUTtBQUFBQSxjQUFjO0FBQUEsY0FBb0JSLE1BQU1VO0FBQUFBLGNBQVU7QUFBQSxpQkFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaVixnQkFBTXhDLFNBQVN1QztBQUFBQSxjQUFJLENBQUNrRixTQUFTVCxpQkFDNUIsdUJBQUMsVUFBcUMsV0FBVSx5REFDN0NTO0FBQUFBLHdCQUFRbkM7QUFBQUEsZ0JBQU87QUFBQSxnQkFBSW1DLFFBQVFsQztBQUFBQSxtQkFEbkIsV0FBV3lCLFlBQVksSUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFsQlEsV0FBV3BCLEtBQUssSUFBSXBELE1BQU1DLFVBQVU4SCxRQUFRLENBQUMsSUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxRQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsU0FoZUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtlQTtBQUFBLE9BbmZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvZkE7QUFFSjtBQUFFaEwsR0E1N0JJRCxLQUFhO0FBQUFrTCxLQUFibEw7QUE4N0JOLGVBQWVBO0FBQUksSUFBQWtMO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiVXBsb2FkIiwiRG93bmxvYWQiLCJGaWxlU3ByZWFkc2hlZXQiLCJBcnJvd1JpZ2h0IiwiVHJhc2gyIiwiUm90YXRlQ2N3IiwiSGlzdG9yeSIsIkFsZXJ0Q2lyY2xlIiwiQ2hlY2tDaXJjbGUiLCJJbmZvIiwiTG9nT3V0IiwiRGF0YWJhc2UiLCJYTFNYIiwic3VwYWJhc2UiLCJBdXRoIiwiZG93bmxvYWRTb3VyY2VDb2RlIiwic2F2ZUZpbGVUb1N1cGFiYXNlIiwiZ2V0RmlsZUZyb21TdXBhYmFzZSIsImdldFVzZXJGaWxlcyIsInNhdmVNYXBwaW5nQ29uZmlnIiwic2F2ZVRvSGlzdG9yeSIsImdldFRyYW5zZmVySGlzdG9yeSIsImdldFNhdmVkTWFwcGluZ3MiLCJkZWxldGVNYXBwaW5nQ29uZmlnIiwiQXBwIiwiX3MiLCJ1c2VyIiwic2V0VXNlciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic291cmNlRmlsZSIsInNldFNvdXJjZUZpbGUiLCJkZXN0aW5hdGlvbkZpbGUiLCJzZXREZXN0aW5hdGlvbkZpbGUiLCJtYXBwaW5ncyIsInNldE1hcHBpbmdzIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJub3RpZmljYXRpb24iLCJzZXROb3RpZmljYXRpb24iLCJwcmV2aWV3RGF0YSIsInNldFByZXZpZXdEYXRhIiwic291cmNlRmlsZUlkIiwic2V0U291cmNlRmlsZUlkIiwiZGVzdGluYXRpb25GaWxlSWQiLCJzZXREZXN0aW5hdGlvbkZpbGVJZCIsInNhdmVkRmlsZXMiLCJzZXRTYXZlZEZpbGVzIiwic2F2ZWRNYXBwaW5ncyIsInNldFNhdmVkTWFwcGluZ3MiLCJzaG93U2F2ZU1hcHBpbmdNb2RhbCIsInNldFNob3dTYXZlTWFwcGluZ01vZGFsIiwibWFwcGluZ05hbWUiLCJzZXRNYXBwaW5nTmFtZSIsIlJlYWN0IiwidXNlRWZmZWN0IiwiY2hlY2tBdXRoIiwiZGF0YSIsImF1dGgiLCJnZXRVc2VyIiwibG9hZFNhdmVkRmlsZXMiLCJsb2FkSGlzdG9yeSIsImxvYWRTYXZlZE1hcHBpbmdzIiwic3Vic2NyaXB0aW9uIiwib25BdXRoU3RhdGVDaGFuZ2UiLCJldmVudCIsInNlc3Npb24iLCJ1bnN1YnNjcmliZSIsImZpbGVzIiwiZXJyb3IiLCJjb25zb2xlIiwiaGlzdG9yeURhdGEiLCJmb3JtYXR0ZWRIaXN0b3J5IiwibWFwIiwiZW50cnkiLCJ0aW1lc3RhbXAiLCJEYXRlIiwiY3JlYXRlZF9hdCIsInNvdXJjZV9maWxlIiwibmFtZSIsImRlc3RpbmF0aW9uX2ZpbGUiLCJtYXBwaW5nX2NvbmZpZyIsInJvd3NQcm9jZXNzZWQiLCJyb3dzX3Byb2Nlc3NlZCIsInRvdGFsUm93cyIsInRvdGFsX3Jvd3MiLCJoYW5kbGVMb2dvdXQiLCJzaWduT3V0Iiwic2hvd05vdGlmaWNhdGlvbiIsInR5cGUiLCJtZXNzYWdlIiwic2V0VGltZW91dCIsImhhbmRsZUZpbGVVcGxvYWQiLCJmaWxlIiwidGFyZ2V0IiwicmVhZGVyIiwiRmlsZVJlYWRlciIsIm9ubG9hZCIsImUiLCJVaW50OEFycmF5IiwicmVzdWx0Iiwid29ya2Jvb2siLCJyZWFkIiwic2hlZXROYW1lIiwiU2hlZXROYW1lcyIsIndvcmtzaGVldCIsIlNoZWV0cyIsImpzb25EYXRhIiwidXRpbHMiLCJzaGVldF90b19qc29uIiwiaGVhZGVyIiwibGVuZ3RoIiwiaGVhZGVycyIsInJvd3MiLCJzbGljZSIsImZpbGVEYXRhIiwiZmlsZUlkIiwicmVhZEFzQXJyYXlCdWZmZXIiLCJsb2FkU2F2ZWRGaWxlIiwiYWRkTWFwcGluZyIsInNvdXJjZSIsImRlc3RpbmF0aW9uIiwidHJhbnNmb3JtYXRpb24iLCJyZXBsYWNlUnVsZXMiLCJtYW51YWxWYWx1ZSIsInVwZGF0ZU1hcHBpbmciLCJpbmRleCIsImZpZWxkIiwidmFsdWUiLCJuZXdNYXBwaW5ncyIsInJlbW92ZU1hcHBpbmciLCJmaWx0ZXIiLCJfIiwiaSIsInJlc2V0TWFwcGluZ3MiLCJzYXZlTWFwcGluZ0NvbmZpZ3VyYXRpb24iLCJ0cmltIiwibG9hZE1hcHBpbmdDb25maWd1cmF0aW9uIiwibWFwcGluZ0NvbmZpZyIsInNvdXJjZV9maWxlX2lkIiwiZGVzdGluYXRpb25fZmlsZV9pZCIsImNvbmZpZ0RhdGEiLCJkZWxldGVNYXBwaW5nQ29uZmlndXJhdGlvbiIsIm1hcHBpbmdJZCIsImNvbmZpcm0iLCJhZGRSZXBsYWNlUnVsZSIsIm1hcHBpbmdJbmRleCIsInB1c2giLCJmcm9tIiwidG8iLCJ1cGRhdGVSZXBsYWNlUnVsZSIsInJ1bGVJbmRleCIsInJlbW92ZVJlcGxhY2VSdWxlIiwic3BsaWNlIiwiYXBwbHlUcmFuc2Zvcm1hdGlvbiIsIm1hcHBpbmciLCJ0b1N0cmluZyIsInRvVXBwZXJDYXNlIiwidG9Mb3dlckNhc2UiLCJmb3JFYWNoIiwicnVsZSIsInVuZGVmaW5lZCIsInJlZ2V4IiwiUmVnRXhwIiwicmVwbGFjZSIsImdlbmVyYXRlUHJldmlldyIsInByZXZpZXdSb3dzIiwicm93IiwibmV3Um93IiwiQXJyYXkiLCJmaWxsIiwiZGVzdEluZGV4IiwiaW5kZXhPZiIsInNvdXJjZUluZGV4Iiwic291cmNlVmFsdWUiLCJleHBvcnREYXRhIiwicHJvY2Vzc0V4cG9ydCIsIm9yaWdpbmFsRGVzdGluYXRpb25EYXRhIiwidHJhbnNmb3JtZWREYXRhIiwiZmluYWxEYXRhIiwibG9nIiwibmV3V29ya2Jvb2siLCJib29rX25ldyIsIm5ld1dvcmtzaGVldCIsImFvYV90b19zaGVldCIsImJvb2tfYXBwZW5kX3NoZWV0IiwiZmlsZU5hbWUiLCJ3cml0ZUZpbGUiLCJ0b0xvY2FsZVN0cmluZyIsImNsZWFySGlzdG9yeSIsImYiLCJpZCIsInJvd19jb3VudCIsInVwbG9hZGVkX2F0IiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiY29uZmlnIiwidXBkYXRlZF9hdCIsImhlYWRlckluZGV4Iiwicm93SW5kZXgiLCJjZWxsIiwiY2VsbEluZGV4IiwiZ2V0VGltZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFVwbG9hZCwgRG93bmxvYWQsIEZpbGVTcHJlYWRzaGVldCwgQXJyb3dSaWdodCwgVHJhc2gyLCBSb3RhdGVDY3csIEhpc3RvcnksIEFsZXJ0Q2lyY2xlLCBDaGVja0NpcmNsZSwgSW5mbywgTG9nT3V0LCBEYXRhYmFzZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgKiBhcyBYTFNYIGZyb20gJ3hsc3gnO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tICcuL2xpYi9zdXBhYmFzZSc7XG5pbXBvcnQgQXV0aCBmcm9tICcuL2NvbXBvbmVudHMvQXV0aCc7XG5pbXBvcnQgeyBkb3dubG9hZFNvdXJjZUNvZGUgfSBmcm9tICcuL3V0aWxzL2Rvd25sb2FkU291cmNlJztcbmltcG9ydCB7IFxuICBzYXZlRmlsZVRvU3VwYWJhc2UsIFxuICBnZXRGaWxlRnJvbVN1cGFiYXNlLCBcbiAgZ2V0VXNlckZpbGVzLCBcbiAgc2F2ZU1hcHBpbmdDb25maWcsXG4gIHNhdmVUb0hpc3RvcnksXG4gIGdldFRyYW5zZmVySGlzdG9yeSxcbiAgZGVsZXRlRmlsZSxcbiAgZ2V0U2F2ZWRNYXBwaW5ncyxcbiAgZGVsZXRlTWFwcGluZ0NvbmZpZ1xufSBmcm9tICcuL3NlcnZpY2VzL2ZpbGVTZXJ2aWNlJztcblxuaW50ZXJmYWNlIEZpbGVEYXRhIHtcbiAgbmFtZTogc3RyaW5nO1xuICBoZWFkZXJzOiBzdHJpbmdbXTtcbiAgZGF0YTogYW55W11bXTtcbn1cblxuaW50ZXJmYWNlIENvbHVtbk1hcHBpbmcge1xuICBzb3VyY2U6IHN0cmluZztcbiAgZGVzdGluYXRpb246IHN0cmluZztcbiAgdHJhbnNmb3JtYXRpb246ICdub25lJyB8ICd1cHBlcmNhc2UnIHwgJ2xvd2VyY2FzZScgfCAncmVwbGFjZScgfCAnbWFudWFsJztcbiAgcmVwbGFjZVJ1bGVzPzogeyBmcm9tOiBzdHJpbmc7IHRvOiBzdHJpbmcgfVtdO1xuICBtYW51YWxWYWx1ZT86IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIEhpc3RvcnlFbnRyeSB7XG4gIHRpbWVzdGFtcDogRGF0ZTtcbiAgc291cmNlRmlsZTogc3RyaW5nO1xuICBkZXN0aW5hdGlvbkZpbGU6IHN0cmluZztcbiAgbWFwcGluZ3M6IENvbHVtbk1hcHBpbmdbXTtcbiAgcm93c1Byb2Nlc3NlZDogbnVtYmVyO1xuICB0b3RhbFJvd3M6IG51bWJlcjtcbn1cblxuY29uc3QgQXBwOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGU8YW55PihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtzb3VyY2VGaWxlLCBzZXRTb3VyY2VGaWxlXSA9IHVzZVN0YXRlPEZpbGVEYXRhIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtkZXN0aW5hdGlvbkZpbGUsIHNldERlc3RpbmF0aW9uRmlsZV0gPSB1c2VTdGF0ZTxGaWxlRGF0YSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbWFwcGluZ3MsIHNldE1hcHBpbmdzXSA9IHVzZVN0YXRlPENvbHVtbk1hcHBpbmdbXT4oW10pO1xuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZTxIaXN0b3J5RW50cnlbXT4oW10pO1xuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGU8eyB0eXBlOiAnc3VjY2VzcycgfCAnZXJyb3InIHwgJ2luZm8nOyBtZXNzYWdlOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcHJldmlld0RhdGEsIHNldFByZXZpZXdEYXRhXSA9IHVzZVN0YXRlPGFueVtdW10+KFtdKTtcbiAgY29uc3QgW3NvdXJjZUZpbGVJZCwgc2V0U291cmNlRmlsZUlkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZGVzdGluYXRpb25GaWxlSWQsIHNldERlc3RpbmF0aW9uRmlsZUlkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2F2ZWRGaWxlcywgc2V0U2F2ZWRGaWxlc10gPSB1c2VTdGF0ZTxhbnlbXT4oW10pO1xuICBjb25zdCBbc2F2ZWRNYXBwaW5ncywgc2V0U2F2ZWRNYXBwaW5nc10gPSB1c2VTdGF0ZTxhbnlbXT4oW10pO1xuICBjb25zdCBbc2hvd1NhdmVNYXBwaW5nTW9kYWwsIHNldFNob3dTYXZlTWFwcGluZ01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW21hcHBpbmdOYW1lLCBzZXRNYXBwaW5nTmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gVsOpcmlmaWVyIGwnYXV0aGVudGlmaWNhdGlvbiBhdSBjaGFyZ2VtZW50XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY2hlY2tBdXRoID0gYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XG4gICAgICBzZXRVc2VyKHVzZXIpO1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICBcbiAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgIGxvYWRTYXZlZEZpbGVzKCk7XG4gICAgICAgIGxvYWRIaXN0b3J5KCk7XG4gICAgICAgIGxvYWRTYXZlZE1hcHBpbmdzKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNoZWNrQXV0aCgpO1xuXG4gICAgLy8gw4ljb3V0ZXIgbGVzIGNoYW5nZW1lbnRzIGQnYXV0aGVudGlmaWNhdGlvblxuICAgIGNvbnN0IHsgZGF0YTogeyBzdWJzY3JpcHRpb24gfSB9ID0gc3VwYWJhc2UuYXV0aC5vbkF1dGhTdGF0ZUNoYW5nZSgoZXZlbnQsIHNlc3Npb24pID0+IHtcbiAgICAgIHNldFVzZXIoc2Vzc2lvbj8udXNlciB8fCBudWxsKTtcbiAgICAgIGlmIChzZXNzaW9uPy51c2VyKSB7XG4gICAgICAgIGxvYWRTYXZlZEZpbGVzKCk7XG4gICAgICAgIGxvYWRIaXN0b3J5KCk7XG4gICAgICAgIGxvYWRTYXZlZE1hcHBpbmdzKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gKCkgPT4gc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2FkU2F2ZWRGaWxlcyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZmlsZXMgPSBhd2FpdCBnZXRVc2VyRmlsZXMoKTtcbiAgICAgIHNldFNhdmVkRmlsZXMoZmlsZXMpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGRlcyBmaWNoaWVyczonLCBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGxvYWRTYXZlZE1hcHBpbmdzID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBtYXBwaW5ncyA9IGF3YWl0IGdldFNhdmVkTWFwcGluZ3MoKTtcbiAgICAgIHNldFNhdmVkTWFwcGluZ3MobWFwcGluZ3MpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGRlcyBtYXBwaW5nczonLCBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGxvYWRIaXN0b3J5ID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBoaXN0b3J5RGF0YSA9IGF3YWl0IGdldFRyYW5zZmVySGlzdG9yeSgpO1xuICAgICAgY29uc3QgZm9ybWF0dGVkSGlzdG9yeSA9IGhpc3RvcnlEYXRhLm1hcCgoZW50cnk6IGFueSkgPT4gKHtcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZShlbnRyeS5jcmVhdGVkX2F0KSxcbiAgICAgICAgc291cmNlRmlsZTogZW50cnkuc291cmNlX2ZpbGU/Lm5hbWUgfHwgJ0ZpY2hpZXIgc3VwcHJpbcOpJyxcbiAgICAgICAgZGVzdGluYXRpb25GaWxlOiBlbnRyeS5kZXN0aW5hdGlvbl9maWxlPy5uYW1lIHx8ICdGaWNoaWVyIHN1cHByaW3DqScsXG4gICAgICAgIG1hcHBpbmdzOiBlbnRyeS5tYXBwaW5nX2NvbmZpZyxcbiAgICAgICAgcm93c1Byb2Nlc3NlZDogZW50cnkucm93c19wcm9jZXNzZWQsXG4gICAgICAgIHRvdGFsUm93czogZW50cnkudG90YWxfcm93c1xuICAgICAgfSkpO1xuICAgICAgc2V0SGlzdG9yeShmb3JtYXR0ZWRIaXN0b3J5KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyZXVyIGxvcnMgZHUgY2hhcmdlbWVudCBkZSBsXFwnaGlzdG9yaXF1ZTonLCBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9IGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKTtcbiAgICBzZXRVc2VyKG51bGwpO1xuICAgIHNldFNvdXJjZUZpbGUobnVsbCk7XG4gICAgc2V0RGVzdGluYXRpb25GaWxlKG51bGwpO1xuICAgIHNldE1hcHBpbmdzKFtdKTtcbiAgICBzZXRIaXN0b3J5KFtdKTtcbiAgICBzZXRTYXZlZEZpbGVzKFtdKTtcbiAgICBzZXRTYXZlZE1hcHBpbmdzKFtdKTtcbiAgfTtcblxuICBjb25zdCBzaG93Tm90aWZpY2F0aW9uID0gKHR5cGU6ICdzdWNjZXNzJyB8ICdlcnJvcicgfCAnaW5mbycsIG1lc3NhZ2U6IHN0cmluZykgPT4ge1xuICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGUsIG1lc3NhZ2UgfSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXROb3RpZmljYXRpb24obnVsbCksIDUwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUZpbGVVcGxvYWQgPSB1c2VDYWxsYmFjaygoZXZlbnQ6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+LCB0eXBlOiAnc291cmNlJyB8ICdkZXN0aW5hdGlvbicpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZXZlbnQudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlIHx8ICF1c2VyKSByZXR1cm47XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSBhc3luYyAoZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgY29uc3QgZGF0YSA9IG5ldyBVaW50OEFycmF5KGUudGFyZ2V0Py5yZXN1bHQgYXMgQXJyYXlCdWZmZXIpO1xuICAgICAgICBjb25zdCB3b3JrYm9vayA9IFhMU1gucmVhZChkYXRhLCB7IHR5cGU6ICdhcnJheScgfSk7XG4gICAgICAgIGNvbnN0IHNoZWV0TmFtZSA9IHdvcmtib29rLlNoZWV0TmFtZXNbMF07XG4gICAgICAgIGNvbnN0IHdvcmtzaGVldCA9IHdvcmtib29rLlNoZWV0c1tzaGVldE5hbWVdO1xuICAgICAgICBjb25zdCBqc29uRGF0YSA9IFhMU1gudXRpbHMuc2hlZXRfdG9fanNvbih3b3Jrc2hlZXQsIHsgaGVhZGVyOiAxIH0pIGFzIGFueVtdW107XG4gICAgICAgIFxuICAgICAgICBpZiAoanNvbkRhdGEubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgc2hvd05vdGlmaWNhdGlvbignZXJyb3InLCAnTGUgZmljaGllciBlc3QgdmlkZScpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSBqc29uRGF0YVswXSBhcyBzdHJpbmdbXTtcbiAgICAgICAgY29uc3Qgcm93cyA9IGpzb25EYXRhLnNsaWNlKDEpO1xuXG4gICAgICAgIGNvbnN0IGZpbGVEYXRhOiBGaWxlRGF0YSA9IHtcbiAgICAgICAgICBuYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICBkYXRhOiByb3dzXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gU2F1dmVnYXJkZXIgZGFucyBTdXBhYmFzZVxuICAgICAgICBjb25zdCBmaWxlSWQgPSBhd2FpdCBzYXZlRmlsZVRvU3VwYWJhc2UoZmlsZURhdGEsIHR5cGUpO1xuXG4gICAgICAgIGlmICh0eXBlID09PSAnc291cmNlJykge1xuICAgICAgICAgIHNldFNvdXJjZUZpbGUoZmlsZURhdGEpO1xuICAgICAgICAgIHNldFNvdXJjZUZpbGVJZChmaWxlSWQpO1xuICAgICAgICAgIHNob3dOb3RpZmljYXRpb24oJ3N1Y2Nlc3MnLCBgRmljaGllciBzb3VyY2UgXCIke2ZpbGUubmFtZX1cIiBjaGFyZ8OpIGF2ZWMgc3VjY8OocyAoJHtyb3dzLmxlbmd0aH0gbGlnbmVzKWApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldERlc3RpbmF0aW9uRmlsZShmaWxlRGF0YSk7XG4gICAgICAgICAgc2V0RGVzdGluYXRpb25GaWxlSWQoZmlsZUlkKTtcbiAgICAgICAgICBzaG93Tm90aWZpY2F0aW9uKCdzdWNjZXNzJywgYEZpY2hpZXIgZGVzdGluYXRpb24gXCIke2ZpbGUubmFtZX1cIiBjaGFyZ8OpIGF2ZWMgc3VjY8OocyAoJHtyb3dzLmxlbmd0aH0gbGlnbmVzKWApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUmVjaGFyZ2VyIGxhIGxpc3RlIGRlcyBmaWNoaWVyc1xuICAgICAgICBsb2FkU2F2ZWRGaWxlcygpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyZXVyOicsIGVycm9yKTtcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbignZXJyb3InLCAnRXJyZXVyIGxvcnMgZGUgbGEgbGVjdHVyZSBvdSBzYXV2ZWdhcmRlIGR1IGZpY2hpZXInKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0FycmF5QnVmZmVyKGZpbGUpO1xuICB9LCBbdXNlcl0pO1xuXG4gIGNvbnN0IGxvYWRTYXZlZEZpbGUgPSBhc3luYyAoZmlsZUlkOiBzdHJpbmcsIHR5cGU6ICdzb3VyY2UnIHwgJ2Rlc3RpbmF0aW9uJykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgY29uc3QgZmlsZURhdGEgPSBhd2FpdCBnZXRGaWxlRnJvbVN1cGFiYXNlKGZpbGVJZCk7XG4gICAgICBcbiAgICAgIGlmICh0eXBlID09PSAnc291cmNlJykge1xuICAgICAgICBzZXRTb3VyY2VGaWxlKGZpbGVEYXRhKTtcbiAgICAgICAgc2V0U291cmNlRmlsZUlkKGZpbGVJZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXREZXN0aW5hdGlvbkZpbGUoZmlsZURhdGEpO1xuICAgICAgICBzZXREZXN0aW5hdGlvbkZpbGVJZChmaWxlSWQpO1xuICAgICAgfVxuICAgICAgXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdzdWNjZXNzJywgYEZpY2hpZXIgJHt0eXBlfSBcIiR7ZmlsZURhdGEubmFtZX1cIiBjaGFyZ8OpIGRlcHVpcyBsYSBiYXNlIGRlIGRvbm7DqWVzYCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0VycmV1cjonLCBlcnJvcik7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdlcnJvcicsICdFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGR1IGZpY2hpZXInKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGFkZE1hcHBpbmcgPSAoKSA9PiB7XG4gICAgc2V0TWFwcGluZ3MoWy4uLm1hcHBpbmdzLCB7IFxuICAgICAgc291cmNlOiAnJywgXG4gICAgICBkZXN0aW5hdGlvbjogJycsIFxuICAgICAgdHJhbnNmb3JtYXRpb246ICdub25lJyxcbiAgICAgIHJlcGxhY2VSdWxlczogW10sXG4gICAgICBtYW51YWxWYWx1ZTogJydcbiAgICB9XSk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlTWFwcGluZyA9IChpbmRleDogbnVtYmVyLCBmaWVsZDoga2V5b2YgQ29sdW1uTWFwcGluZywgdmFsdWU6IGFueSkgPT4ge1xuICAgIGNvbnN0IG5ld01hcHBpbmdzID0gWy4uLm1hcHBpbmdzXTtcbiAgICBpZiAoZmllbGQgPT09ICdyZXBsYWNlUnVsZXMnKSB7XG4gICAgICBuZXdNYXBwaW5nc1tpbmRleF1bZmllbGRdID0gdmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIChuZXdNYXBwaW5nc1tpbmRleF0gYXMgYW55KVtmaWVsZF0gPSB2YWx1ZTtcbiAgICB9XG4gICAgc2V0TWFwcGluZ3MobmV3TWFwcGluZ3MpO1xuICB9O1xuXG4gIGNvbnN0IHJlbW92ZU1hcHBpbmcgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgIHNldE1hcHBpbmdzKG1hcHBpbmdzLmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcbiAgfTtcblxuICBjb25zdCByZXNldE1hcHBpbmdzID0gKCkgPT4ge1xuICAgIHNldE1hcHBpbmdzKFtdKTtcbiAgICBzaG93Tm90aWZpY2F0aW9uKCdpbmZvJywgJ01hcHBpbmdzIHLDqWluaXRpYWxpc8OpcycpO1xuICB9O1xuXG4gIGNvbnN0IHNhdmVNYXBwaW5nQ29uZmlndXJhdGlvbiA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXNvdXJjZUZpbGVJZCB8fCAhZGVzdGluYXRpb25GaWxlSWQgfHwgbWFwcGluZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdlcnJvcicsICdWZXVpbGxleiBjaGFyZ2VyIGxlcyBmaWNoaWVycyBldCBkw6lmaW5pciBhdSBtb2lucyB1biBtYXBwaW5nJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKCFtYXBwaW5nTmFtZS50cmltKCkpIHtcbiAgICAgIHNob3dOb3RpZmljYXRpb24oJ2Vycm9yJywgJ1ZldWlsbGV6IGRvbm5lciB1biBub20gw6Agdm90cmUgY29uZmlndXJhdGlvbicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzYXZlTWFwcGluZ0NvbmZpZyhzb3VyY2VGaWxlSWQsIGRlc3RpbmF0aW9uRmlsZUlkLCBtYXBwaW5ncywgbWFwcGluZ05hbWUpO1xuICAgICAgc2hvd05vdGlmaWNhdGlvbignc3VjY2VzcycsIGBDb25maWd1cmF0aW9uIFwiJHttYXBwaW5nTmFtZX1cIiBzYXV2ZWdhcmTDqWVgKTtcbiAgICAgIHNldFNob3dTYXZlTWFwcGluZ01vZGFsKGZhbHNlKTtcbiAgICAgIHNldE1hcHBpbmdOYW1lKCcnKTtcbiAgICAgIGxvYWRTYXZlZE1hcHBpbmdzKCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0VycmV1cjonLCBlcnJvcik7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdlcnJvcicsICdFcnJldXIgbG9ycyBkZSBsYSBzYXV2ZWdhcmRlJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGxvYWRNYXBwaW5nQ29uZmlndXJhdGlvbiA9IGFzeW5jIChtYXBwaW5nQ29uZmlnOiBhbnkpID0+IHtcbiAgICB0cnkge1xuICAgICAgLy8gQ2hhcmdlciBsZXMgZmljaGllcnMgc291cmNlIGV0IGRlc3RpbmF0aW9uXG4gICAgICBhd2FpdCBsb2FkU2F2ZWRGaWxlKG1hcHBpbmdDb25maWcuc291cmNlX2ZpbGVfaWQsICdzb3VyY2UnKTtcbiAgICAgIGF3YWl0IGxvYWRTYXZlZEZpbGUobWFwcGluZ0NvbmZpZy5kZXN0aW5hdGlvbl9maWxlX2lkLCAnZGVzdGluYXRpb24nKTtcbiAgICAgIFxuICAgICAgLy8gQ2hhcmdlciBsZXMgbWFwcGluZ3NcbiAgICAgIGNvbnN0IGNvbmZpZ0RhdGEgPSBtYXBwaW5nQ29uZmlnLm1hcHBpbmdfY29uZmlnO1xuICAgICAgc2V0TWFwcGluZ3MoY29uZmlnRGF0YS5tYXBwaW5ncyB8fCBbXSk7XG4gICAgICBcbiAgICAgIHNob3dOb3RpZmljYXRpb24oJ3N1Y2Nlc3MnLCBgQ29uZmlndXJhdGlvbiBcIiR7Y29uZmlnRGF0YS5uYW1lfVwiIGNoYXJnw6llYCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0VycmV1cjonLCBlcnJvcik7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdlcnJvcicsICdFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGRlIGxhIGNvbmZpZ3VyYXRpb24nKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZGVsZXRlTWFwcGluZ0NvbmZpZ3VyYXRpb24gPSBhc3luYyAobWFwcGluZ0lkOiBzdHJpbmcsIG5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICghY29uZmlybShgw4p0ZXMtdm91cyBzw7tyIGRlIHZvdWxvaXIgc3VwcHJpbWVyIGxhIGNvbmZpZ3VyYXRpb24gXCIke25hbWV9XCIgP2ApKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGRlbGV0ZU1hcHBpbmdDb25maWcobWFwcGluZ0lkKTtcbiAgICAgIHNob3dOb3RpZmljYXRpb24oJ3N1Y2Nlc3MnLCBgQ29uZmlndXJhdGlvbiBcIiR7bmFtZX1cIiBzdXBwcmltw6llYCk7XG4gICAgICBsb2FkU2F2ZWRNYXBwaW5ncygpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJldXI6JywgZXJyb3IpO1xuICAgICAgc2hvd05vdGlmaWNhdGlvbignZXJyb3InLCAnRXJyZXVyIGxvcnMgZGUgbGEgc3VwcHJlc3Npb24nKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgYWRkUmVwbGFjZVJ1bGUgPSAobWFwcGluZ0luZGV4OiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBuZXdNYXBwaW5ncyA9IFsuLi5tYXBwaW5nc107XG4gICAgaWYgKCFuZXdNYXBwaW5nc1ttYXBwaW5nSW5kZXhdLnJlcGxhY2VSdWxlcykge1xuICAgICAgbmV3TWFwcGluZ3NbbWFwcGluZ0luZGV4XS5yZXBsYWNlUnVsZXMgPSBbXTtcbiAgICB9XG4gICAgbmV3TWFwcGluZ3NbbWFwcGluZ0luZGV4XS5yZXBsYWNlUnVsZXMhLnB1c2goeyBmcm9tOiAnJywgdG86ICcnIH0pO1xuICAgIHNldE1hcHBpbmdzKG5ld01hcHBpbmdzKTtcbiAgfTtcblxuICBjb25zdCB1cGRhdGVSZXBsYWNlUnVsZSA9IChtYXBwaW5nSW5kZXg6IG51bWJlciwgcnVsZUluZGV4OiBudW1iZXIsIGZpZWxkOiAnZnJvbScgfCAndG8nLCB2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgbmV3TWFwcGluZ3MgPSBbLi4ubWFwcGluZ3NdO1xuICAgIGlmIChuZXdNYXBwaW5nc1ttYXBwaW5nSW5kZXhdLnJlcGxhY2VSdWxlcykge1xuICAgICAgbmV3TWFwcGluZ3NbbWFwcGluZ0luZGV4XS5yZXBsYWNlUnVsZXMhW3J1bGVJbmRleF1bZmllbGRdID0gdmFsdWU7XG4gICAgICBzZXRNYXBwaW5ncyhuZXdNYXBwaW5ncyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHJlbW92ZVJlcGxhY2VSdWxlID0gKG1hcHBpbmdJbmRleDogbnVtYmVyLCBydWxlSW5kZXg6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IG5ld01hcHBpbmdzID0gWy4uLm1hcHBpbmdzXTtcbiAgICBpZiAobmV3TWFwcGluZ3NbbWFwcGluZ0luZGV4XS5yZXBsYWNlUnVsZXMpIHtcbiAgICAgIG5ld01hcHBpbmdzW21hcHBpbmdJbmRleF0ucmVwbGFjZVJ1bGVzIS5zcGxpY2UocnVsZUluZGV4LCAxKTtcbiAgICAgIHNldE1hcHBpbmdzKG5ld01hcHBpbmdzKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRm9uY3Rpb24gcG91ciBhcHBsaXF1ZXIgbGVzIHRyYW5zZm9ybWF0aW9uc1xuICBjb25zdCBhcHBseVRyYW5zZm9ybWF0aW9uID0gKHZhbHVlOiBzdHJpbmcsIG1hcHBpbmc6IENvbHVtbk1hcHBpbmcpOiBzdHJpbmcgPT4ge1xuICAgIGlmICghdmFsdWUgJiYgbWFwcGluZy50cmFuc2Zvcm1hdGlvbiAhPT0gJ21hbnVhbCcpIHJldHVybiAnJztcbiAgICBcbiAgICBzd2l0Y2ggKG1hcHBpbmcudHJhbnNmb3JtYXRpb24pIHtcbiAgICAgIGNhc2UgJ3VwcGVyY2FzZSc6XG4gICAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpLnRvVXBwZXJDYXNlKCk7XG4gICAgICBjYXNlICdsb3dlcmNhc2UnOlxuICAgICAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgY2FzZSAncmVwbGFjZSc6XG4gICAgICAgIGxldCByZXN1bHQgPSB2YWx1ZS50b1N0cmluZygpO1xuICAgICAgICBtYXBwaW5nLnJlcGxhY2VSdWxlcz8uZm9yRWFjaChydWxlID0+IHtcbiAgICAgICAgICBpZiAocnVsZS5mcm9tICYmIHJ1bGUudG8gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKHJ1bGUuZnJvbS5yZXBsYWNlKC9bLiorP14ke30oKXxbXFxdXFxcXF0vZywgJ1xcXFwkJicpLCAnZ2knKTtcbiAgICAgICAgICAgIHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKHJlZ2V4LCBydWxlLnRvKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgY2FzZSAnbWFudWFsJzpcbiAgICAgICAgcmV0dXJuIG1hcHBpbmcubWFudWFsVmFsdWUgfHwgJyc7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRm9uY3Rpb24gcG91ciBnw6luw6lyZXIgbGEgcHLDqXZpc3VhbGlzYXRpb25cbiAgY29uc3QgZ2VuZXJhdGVQcmV2aWV3ID0gKCkgPT4ge1xuICAgIGlmICghc291cmNlRmlsZSB8fCAhZGVzdGluYXRpb25GaWxlIHx8IG1hcHBpbmdzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgc2V0UHJldmlld0RhdGEoW10pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFByZW5kcmUgbGVzIDUgcHJlbWnDqHJlcyBsaWduZXMgcG91ciBsYSBwcsOpdmlzdWFsaXNhdGlvblxuICAgIGNvbnN0IHByZXZpZXdSb3dzID0gc291cmNlRmlsZS5kYXRhLnNsaWNlKDAsIDUpLm1hcChyb3cgPT4ge1xuICAgICAgY29uc3QgbmV3Um93ID0gbmV3IEFycmF5KGRlc3RpbmF0aW9uRmlsZS5oZWFkZXJzLmxlbmd0aCkuZmlsbCgnJyk7XG4gICAgICBcbiAgICAgIG1hcHBpbmdzLmZvckVhY2gobWFwcGluZyA9PiB7XG4gICAgICAgIGNvbnN0IGRlc3RJbmRleCA9IGRlc3RpbmF0aW9uRmlsZS5oZWFkZXJzLmluZGV4T2YobWFwcGluZy5kZXN0aW5hdGlvbik7XG4gICAgICAgIFxuICAgICAgICBpZiAoZGVzdEluZGV4ICE9PSAtMSkge1xuICAgICAgICAgIGlmIChtYXBwaW5nLnRyYW5zZm9ybWF0aW9uID09PSAnbWFudWFsJykge1xuICAgICAgICAgICAgLy8gUG91ciBsZXMgdmFsZXVycyBtYW51ZWxsZXMsIG9uIHV0aWxpc2UgZGlyZWN0ZW1lbnQgbGEgdmFsZXVyIHNhaXNpZVxuICAgICAgICAgICAgbmV3Um93W2Rlc3RJbmRleF0gPSBhcHBseVRyYW5zZm9ybWF0aW9uKCcnLCBtYXBwaW5nKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gUG91ciBsZXMgYXV0cmVzIHRyYW5zZm9ybWF0aW9ucywgb24gdXRpbGlzZSBsYSB2YWxldXIgc291cmNlXG4gICAgICAgICAgICBjb25zdCBzb3VyY2VJbmRleCA9IHNvdXJjZUZpbGUuaGVhZGVycy5pbmRleE9mKG1hcHBpbmcuc291cmNlKTtcbiAgICAgICAgICAgIGlmIChzb3VyY2VJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgY29uc3Qgc291cmNlVmFsdWUgPSByb3dbc291cmNlSW5kZXhdIHx8ICcnO1xuICAgICAgICAgICAgICBuZXdSb3dbZGVzdEluZGV4XSA9IGFwcGx5VHJhbnNmb3JtYXRpb24oc291cmNlVmFsdWUsIG1hcHBpbmcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIHJldHVybiBuZXdSb3c7XG4gICAgfSk7XG5cbiAgICBzZXRQcmV2aWV3RGF0YShwcmV2aWV3Um93cyk7XG4gIH07XG5cbiAgLy8gTWV0dHJlIMOgIGpvdXIgbGEgcHLDqXZpc3VhbGlzYXRpb24gcXVhbmQgbGVzIG1hcHBpbmdzIGNoYW5nZW50XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZ2VuZXJhdGVQcmV2aWV3KCk7XG4gIH0sIFttYXBwaW5ncywgc291cmNlRmlsZSwgZGVzdGluYXRpb25GaWxlXSk7XG4gIFxuICBjb25zdCBleHBvcnREYXRhID0gKCkgPT4ge1xuICAgIGlmICghc291cmNlRmlsZSB8fCAhZGVzdGluYXRpb25GaWxlIHx8IG1hcHBpbmdzLmxlbmd0aCA9PT0gMCB8fCAhc291cmNlRmlsZUlkIHx8ICFkZXN0aW5hdGlvbkZpbGVJZCkge1xuICAgICAgc2hvd05vdGlmaWNhdGlvbignZXJyb3InLCAnVmV1aWxsZXogY2hhcmdlciBsZXMgZmljaGllcnMgZXQgZMOpZmluaXIgYXUgbW9pbnMgdW4gbWFwcGluZycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHByb2Nlc3NFeHBvcnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAvLyBDcsOpZXIgdW5lIGNvcGllIGNvbXBsw6h0ZSBkZXMgZG9ubsOpZXMgZGUgZGVzdGluYXRpb24gU0FOUyBsZXMgbW9kaWZpZXJcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxEZXN0aW5hdGlvbkRhdGEgPSBbZGVzdGluYXRpb25GaWxlLmhlYWRlcnMsIC4uLmRlc3RpbmF0aW9uRmlsZS5kYXRhXTtcbiAgICAgICAgXG4gICAgICAgIC8vIFRyYW5zZm9ybWVyIGxlcyBkb25uw6llcyBzb3VyY2Ugc2Vsb24gbGVzIG1hcHBpbmdzXG4gICAgICAgIGNvbnN0IHRyYW5zZm9ybWVkRGF0YSA9IHNvdXJjZUZpbGUuZGF0YS5tYXAocm93ID0+IHtcbiAgICAgICAgICBjb25zdCBuZXdSb3cgPSBuZXcgQXJyYXkoZGVzdGluYXRpb25GaWxlLmhlYWRlcnMubGVuZ3RoKS5maWxsKCcnKTtcbiAgICAgICAgICBcbiAgICAgICAgICBtYXBwaW5ncy5mb3JFYWNoKG1hcHBpbmcgPT4ge1xuICAgICAgICAgICAgY29uc3QgZGVzdEluZGV4ID0gZGVzdGluYXRpb25GaWxlLmhlYWRlcnMuaW5kZXhPZihtYXBwaW5nLmRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgaWYgKGRlc3RJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgaWYgKG1hcHBpbmcudHJhbnNmb3JtYXRpb24gPT09ICdtYW51YWwnKSB7XG4gICAgICAgICAgICAgICAgLy8gUG91ciBsZXMgdmFsZXVycyBtYW51ZWxsZXMsIG9uIHV0aWxpc2UgZGlyZWN0ZW1lbnQgbGEgdmFsZXVyIHNhaXNpZVxuICAgICAgICAgICAgICAgIG5ld1Jvd1tkZXN0SW5kZXhdID0gYXBwbHlUcmFuc2Zvcm1hdGlvbignJywgbWFwcGluZyk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gUG91ciBsZXMgYXV0cmVzIHRyYW5zZm9ybWF0aW9ucywgb24gdXRpbGlzZSBsYSB2YWxldXIgc291cmNlXG4gICAgICAgICAgICAgICAgY29uc3Qgc291cmNlSW5kZXggPSBzb3VyY2VGaWxlLmhlYWRlcnMuaW5kZXhPZihtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgICAgICAgaWYgKHNvdXJjZUluZGV4ICE9PSAtMSkge1xuICAgICAgICAgICAgICAgICAgY29uc3Qgc291cmNlVmFsdWUgPSByb3dbc291cmNlSW5kZXhdIHx8ICcnO1xuICAgICAgICAgICAgICAgICAgbmV3Um93W2Rlc3RJbmRleF0gPSBhcHBseVRyYW5zZm9ybWF0aW9uKHNvdXJjZVZhbHVlLCBtYXBwaW5nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICBcbiAgICAgICAgICByZXR1cm4gbmV3Um93O1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBWUkFJRSBQUsOJU0VSVkFUSU9OIDogQ29tYmluZXIgbGVzIGRvbm7DqWVzIFNBTlMgbW9kaWZpZXIgbCdvcmlnaW5hbFxuICAgICAgICBjb25zdCBmaW5hbERhdGEgPSBbXG4gICAgICAgICAgLi4ub3JpZ2luYWxEZXN0aW5hdGlvbkRhdGEsICAvLyBUT1VURVMgbGVzIGRvbm7DqWVzIGV4aXN0YW50ZXMgKGVuLXTDqnRlICsgbGlnbmVzKVxuICAgICAgICAgIC4uLnRyYW5zZm9ybWVkRGF0YSAgICAgICAgICAgLy8gTm91dmVsbGVzIGRvbm7DqWVzIHRyYW5zZm9ybcOpZXNcbiAgICAgICAgXTtcblxuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBEb25uw6llcyBvcmlnaW5hbGVzIGRlc3RpbmF0aW9uOicsIG9yaWdpbmFsRGVzdGluYXRpb25EYXRhLmxlbmd0aCwgJ2xpZ25lcycpO1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBOb3V2ZWxsZXMgZG9ubsOpZXMgw6AgYWpvdXRlcjonLCB0cmFuc2Zvcm1lZERhdGEubGVuZ3RoLCAnbGlnbmVzJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIFRvdGFsIGZpbmFsOicsIGZpbmFsRGF0YS5sZW5ndGgsICdsaWduZXMnKTtcblxuICAgICAgICAvLyBDcsOpZXIgbGUgbm91dmVhdSB3b3JrYm9va1xuICAgICAgICBjb25zdCBuZXdXb3JrYm9vayA9IFhMU1gudXRpbHMuYm9va19uZXcoKTtcbiAgICAgICAgY29uc3QgbmV3V29ya3NoZWV0ID0gWExTWC51dGlscy5hb2FfdG9fc2hlZXQoZmluYWxEYXRhKTtcbiAgICAgICAgWExTWC51dGlscy5ib29rX2FwcGVuZF9zaGVldChuZXdXb3JrYm9vaywgbmV3V29ya3NoZWV0LCAnU2hlZXQxJyk7XG5cbiAgICAgICAgLy8gVMOpbMOpY2hhcmdlclxuICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2Rlc3RpbmF0aW9uRmlsZS5uYW1lLnJlcGxhY2UoJy54bHN4JywgJycpfV91cGRhdGVkLnhsc3hgO1xuICAgICAgICBYTFNYLndyaXRlRmlsZShuZXdXb3JrYm9vaywgZmlsZU5hbWUpO1xuXG4gICAgICAgIC8vIFNhdXZlZ2FyZGVyIGxhIGNvbmZpZ3VyYXRpb24gZGUgbWFwcGluZ1xuICAgICAgICBhd2FpdCBzYXZlTWFwcGluZ0NvbmZpZyhzb3VyY2VGaWxlSWQsIGRlc3RpbmF0aW9uRmlsZUlkLCBtYXBwaW5ncywgYEV4cG9ydCAke25ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKX1gKTtcblxuICAgICAgICAvLyBBam91dGVyIMOgIGwnaGlzdG9yaXF1ZSBkYW5zIFN1cGFiYXNlXG4gICAgICAgIGF3YWl0IHNhdmVUb0hpc3RvcnkoXG4gICAgICAgICAgc291cmNlRmlsZUlkLFxuICAgICAgICAgIGRlc3RpbmF0aW9uRmlsZUlkLFxuICAgICAgICAgIG1hcHBpbmdzLFxuICAgICAgICAgIHRyYW5zZm9ybWVkRGF0YS5sZW5ndGgsXG4gICAgICAgICAgZmluYWxEYXRhLmxlbmd0aCAtIDFcbiAgICAgICAgKTtcblxuICAgICAgICAvLyBSZWNoYXJnZXIgbCdoaXN0b3JpcXVlXG4gICAgICAgIGF3YWl0IGxvYWRIaXN0b3J5KCk7XG4gICAgICAgIGxvYWRTYXZlZE1hcHBpbmdzKCk7XG5cbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbignc3VjY2VzcycsIFxuICAgICAgICAgIGBFeHBvcnQgcsOpdXNzaSAhICR7b3JpZ2luYWxEZXN0aW5hdGlvbkRhdGEubGVuZ3RoIC0gMX0gbGlnbmVzIGNvbnNlcnbDqWVzICsgJHt0cmFuc2Zvcm1lZERhdGEubGVuZ3RofSBub3V2ZWxsZXMgbGlnbmVzID0gJHtmaW5hbERhdGEubGVuZ3RoIC0gMX0gbGlnbmVzIGF1IHRvdGFsYFxuICAgICAgICApO1xuXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJldXIgZXhwb3J0OicsIGVycm9yKTtcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbignZXJyb3InLCAnRXJyZXVyIGxvcnMgZGUgbFxcJ2V4cG9ydCBkZXMgZG9ubsOpZXMnKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBwcm9jZXNzRXhwb3J0KCk7XG4gIH07XG5cbiAgY29uc3QgY2xlYXJIaXN0b3J5ID0gKCkgPT4ge1xuICAgIHNldEhpc3RvcnkoW10pO1xuICAgIHNob3dOb3RpZmljYXRpb24oJ2luZm8nLCAnSGlzdG9yaXF1ZSBlZmZhY8OpJyk7XG4gIH07XG5cbiAgLy8gQWZmaWNoZXIgbCfDqWNyYW4gZCdhdXRoZW50aWZpY2F0aW9uIHNpIHBhcyBjb25uZWN0w6lcbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHZpYS13aGl0ZSB0by1jeWFuLTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8RGF0YWJhc2UgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHRleHQtYmx1ZS02MDAgbXgtYXV0byBtYi00IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCB0ZXh0LWdyYXktNjAwXCI+Q2hhcmdlbWVudC4uLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgaWYgKCF1c2VyKSB7XG4gICAgcmV0dXJuIDxBdXRoIG9uQXV0aFN1Y2Nlc3M9eygpID0+IHNldFVzZXIodHJ1ZSl9IC8+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdmlhLXdoaXRlIHRvLWN5YW4tNTBcIj5cbiAgICAgIHsvKiBOb3RpZmljYXRpb24gKi99XG4gICAgICB7bm90aWZpY2F0aW9uICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmaXhlZCB0b3AtNCByaWdodC00IHotNTAgcC00IHJvdW5kZWQtbGcgc2hhZG93LWxnIGFuaW1hdGUtc2xpZGUtdXAgJHtcbiAgICAgICAgICBub3RpZmljYXRpb24udHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJ2JnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlJyA6XG4gICAgICAgICAgbm90aWZpY2F0aW9uLnR5cGUgPT09ICdlcnJvcicgPyAnYmctcmVkLTUwMCB0ZXh0LXdoaXRlJyA6XG4gICAgICAgICAgJ2JnLWJsdWUtNTAwIHRleHQtd2hpdGUnXG4gICAgICAgIH1gfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICB7bm90aWZpY2F0aW9uLnR5cGUgPT09ICdzdWNjZXNzJyAmJiA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+fVxuICAgICAgICAgICAge25vdGlmaWNhdGlvbi50eXBlID09PSAnZXJyb3InICYmIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XG4gICAgICAgICAgICB7bm90aWZpY2F0aW9uLnR5cGUgPT09ICdpbmZvJyAmJiA8SW5mbyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XG4gICAgICAgICAgICB7bm90aWZpY2F0aW9uLm1lc3NhZ2V9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgbXgtYXV0byBweC00IHB5LThcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi04IGFuaW1hdGUtZmFkZS1pblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgbWItNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPEZpbGVTcHJlYWRzaGVldCBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1ibHVlLTYwMFwiIC8+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1jeWFuLTYwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxuICAgICAgICAgICAgICBQbGF0ZWZvcm1lIGRlIFRyYW5zZmVydCBFeGNlbFxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Rvd25sb2FkU291cmNlQ29kZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmVlbi0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIENvZGUgU291cmNlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTggZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIGJnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIHJvdW5kZWQtbGcgaG92ZXI6YmctcmVkLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIETDqWNvbm5leGlvblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgdGV4dC1ncmF5LTYwMCBtYXgtdy0yeGwgbXgtYXV0b1wiPlxuICAgICAgICAgICAgVHJhbnNmw6lyZXogZmFjaWxlbWVudCB2b3MgZG9ubsOpZXMgZW50cmUgZmljaGllcnMgRXhjZWwgYXZlYyBzdG9ja2FnZSBzw6ljdXJpc8OpIGRhbnMgU3VwYWJhc2VcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBGaWNoaWVycyBzYXV2ZWdhcmTDqXMgKi99XG4gICAgICAgIHtzYXZlZEZpbGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXhsIHAtNiBtYi04IGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPERhdGFiYXNlIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ncmVlbi02MDBcIiAvPlxuICAgICAgICAgICAgICBGaWNoaWVycyBzYXV2ZWdhcmTDqXMgKHtzYXZlZEZpbGVzLmxlbmd0aH0pXG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTgwMCBtYi0yXCI+RmljaGllcnMgU291cmNlPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAge3NhdmVkRmlsZXMuZmlsdGVyKGYgPT4gZi50eXBlID09PSAnc291cmNlJykubWFwKChmaWxlKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2ZpbGUuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbG9hZFNhdmVkRmlsZShmaWxlLmlkLCAnc291cmNlJyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBwLTMgYmctYmx1ZS01MCByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ibHVlLTgwMFwiPntmaWxlLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS02MDBcIj57ZmlsZS5yb3dfY291bnR9IGxpZ25lcyDigKIge25ldyBEYXRlKGZpbGUudXBsb2FkZWRfYXQpLnRvTG9jYWxlRGF0ZVN0cmluZygpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWN5YW4tODAwIG1iLTJcIj5GaWNoaWVycyBEZXN0aW5hdGlvbjwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIHtzYXZlZEZpbGVzLmZpbHRlcihmID0+IGYudHlwZSA9PT0gJ2Rlc3RpbmF0aW9uJykubWFwKChmaWxlKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2ZpbGUuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbG9hZFNhdmVkRmlsZShmaWxlLmlkLCAnZGVzdGluYXRpb24nKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHAtMyBiZy1jeWFuLTUwIHJvdW5kZWQtbGcgaG92ZXI6YmctY3lhbi0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWN5YW4tODAwXCI+e2ZpbGUubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1jeWFuLTYwMFwiPntmaWxlLnJvd19jb3VudH0gbGlnbmVzIOKAoiB7bmV3IERhdGUoZmlsZS51cGxvYWRlZF9hdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIENvbmZpZ3VyYXRpb25zIGRlIG1hcHBpbmcgc2F1dmVnYXJkw6llcyAqL31cbiAgICAgICAge3NhdmVkTWFwcGluZ3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3cteGwgcC02IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtcHVycGxlLTYwMFwiIC8+XG4gICAgICAgICAgICAgIENvbmZpZ3VyYXRpb25zIGRlIG1hcHBpbmcgc2F1dmVnYXJkw6llcyAoe3NhdmVkTWFwcGluZ3MubGVuZ3RofSlcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAge3NhdmVkTWFwcGluZ3MubWFwKChjb25maWcpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y29uZmlnLmlkfSBjbGFzc05hbWU9XCJwLTQgYmctcHVycGxlLTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtcHVycGxlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NvbmZpZy5tYXBwaW5nX2NvbmZpZy5uYW1lIHx8ICdDb25maWd1cmF0aW9uIHNhbnMgbm9tJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wdXJwbGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y29uZmlnLnNvdXJjZV9maWxlPy5uYW1lfSDihpIge2NvbmZpZy5kZXN0aW5hdGlvbl9maWxlPy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcHVycGxlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NvbmZpZy5tYXBwaW5nX2NvbmZpZy5tYXBwaW5ncz8ubGVuZ3RoIHx8IDB9IG1hcHBpbmdzIOKAoiB7bmV3IERhdGUoY29uZmlnLnVwZGF0ZWRfYXQpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbG9hZE1hcHBpbmdDb25maWd1cmF0aW9uKGNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctcHVycGxlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6YmctcHVycGxlLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBDaGFyZ2VyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVsZXRlTWFwcGluZ0NvbmZpZ3VyYXRpb24oY29uZmlnLmlkLCBjb25maWcubWFwcGluZ19jb25maWcubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1yZWQtMjAwIHRyYW5zaXRpb24tY29sb3JzIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIEZpbGUgVXBsb2FkIFNlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtZDpncmlkLWNvbHMtMiBnYXAtOCBtYi0xMlwiPlxuICAgICAgICAgIHsvKiBTb3VyY2UgRmlsZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy14bCBwLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBhbmltYXRlLXNjYWxlLWluXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cbiAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtYmx1ZS02MDBcIiAvPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5GaWNoaWVyIFNvdXJjZTwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ibHVlLTMwMCByb3VuZGVkLXhsIHAtOCB0ZXh0LWNlbnRlciBob3Zlcjpib3JkZXItYmx1ZS00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgIGFjY2VwdD1cIi54bHN4LC54bHNcIlxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZVVwbG9hZChlLCAnc291cmNlJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICBpZD1cInNvdXJjZS11cGxvYWRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInNvdXJjZS11cGxvYWRcIiBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIDxGaWxlU3ByZWFkc2hlZXQgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHRleHQtYmx1ZS00MDAgbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAge3NvdXJjZUZpbGUgPyBg4pyFICR7c291cmNlRmlsZS5uYW1lfWAgOiAnQ2xpcXVleiBwb3VyIHPDqWxlY3Rpb25uZXIgbGUgZmljaGllciBzb3VyY2UnfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtzb3VyY2VGaWxlID8gYCR7c291cmNlRmlsZS5kYXRhLmxlbmd0aH0gbGlnbmVzLCAke3NvdXJjZUZpbGUuaGVhZGVycy5sZW5ndGh9IGNvbG9ubmVzIOKAoiBTYXV2ZWdhcmTDqSBkYW5zIFN1cGFiYXNlYCA6ICdGb3JtYXRzIHN1cHBvcnTDqXM6IC54bHN4LCAueGxzJ31cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3NvdXJjZUZpbGUgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcC00IGJnLWJsdWUtNTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmx1ZS04MDAgbWItMlwiPkNvbG9ubmVzIGRpc3BvbmlibGVzOjwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAge3NvdXJjZUZpbGUuaGVhZGVycy5tYXAoKGhlYWRlciwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtgc291cmNlLWhlYWRlci0ke2luZGV4fWB9IGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwIHJvdW5kZWQtZnVsbCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2hlYWRlcn1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBEZXN0aW5hdGlvbiBGaWxlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXhsIHAtOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGFuaW1hdGUtc2NhbGUtaW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNlwiPlxuICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LWN5YW4tNjAwXCIgLz5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+RmljaGllciBEZXN0aW5hdGlvbjwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1jeWFuLTMwMCByb3VuZGVkLXhsIHAtOCB0ZXh0LWNlbnRlciBob3Zlcjpib3JkZXItY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgIGFjY2VwdD1cIi54bHN4LC54bHNcIlxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZVVwbG9hZChlLCAnZGVzdGluYXRpb24nKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgIGlkPVwiZGVzdGluYXRpb24tdXBsb2FkXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkZXN0aW5hdGlvbi11cGxvYWRcIiBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIDxGaWxlU3ByZWFkc2hlZXQgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHRleHQtY3lhbi00MDAgbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAge2Rlc3RpbmF0aW9uRmlsZSA/IGDinIUgJHtkZXN0aW5hdGlvbkZpbGUubmFtZX1gIDogJ0NsaXF1ZXogcG91ciBzw6lsZWN0aW9ubmVyIGxlIGZpY2hpZXIgZGVzdGluYXRpb24nfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtkZXN0aW5hdGlvbkZpbGUgPyBgJHtkZXN0aW5hdGlvbkZpbGUuZGF0YS5sZW5ndGh9IGxpZ25lcywgJHtkZXN0aW5hdGlvbkZpbGUuaGVhZGVycy5sZW5ndGh9IGNvbG9ubmVzIOKAoiBTYXV2ZWdhcmTDqSBkYW5zIFN1cGFiYXNlYCA6ICdGb3JtYXRzIHN1cHBvcnTDqXM6IC54bHN4LCAueGxzJ31cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2Rlc3RpbmF0aW9uRmlsZSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBwLTQgYmctY3lhbi01MCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1jeWFuLTgwMCBtYi0yXCI+Q29sb25uZXMgZGlzcG9uaWJsZXM6PC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7ZGVzdGluYXRpb25GaWxlLmhlYWRlcnMubWFwKChoZWFkZXIsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YGRlc3QtaGVhZGVyLSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLWN5YW4tMTAwIHRleHQtY3lhbi04MDAgcm91bmRlZC1mdWxsIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aGVhZGVyfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTWFwcGluZyBTZWN0aW9uICovfVxuICAgICAgICB7c291cmNlRmlsZSAmJiBkZXN0aW5hdGlvbkZpbGUgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXhsIHAtOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIG1iLTggYW5pbWF0ZS1zbGlkZS11cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LXB1cnBsZS02MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPk1hcHBpbmcgZGVzIENvbG9ubmVzPC9oMj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dTYXZlTWFwcGluZ01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21hcHBpbmdzLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERhdGFiYXNlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgU2F1dmVnYXJkZXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZXNldE1hcHBpbmdzfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIFLDqWluaXRpYWxpc2VyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkTWFwcGluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTYgcHktMiBiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1wdXJwbGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIEFqb3V0ZXIgTWFwcGluZ1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7bWFwcGluZ3MubWFwKChtYXBwaW5nLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgbWFwcGluZy0ke2luZGV4fWB9IGNsYXNzTmFtZT1cInAtNiBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAge21hcHBpbmcudHJhbnNmb3JtYXRpb24gIT09ICdtYW51YWwnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+Q29sb25uZSBTb3VyY2U8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFwcGluZy5zb3VyY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlTWFwcGluZyhpbmRleCwgJ3NvdXJjZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHVycGxlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U8OpbGVjdGlvbm5lciB1bmUgY29sb25uZSBzb3VyY2U8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NvdXJjZUZpbGUuaGVhZGVycy5tYXAoKGhlYWRlciwgaGVhZGVySW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YHNvdXJjZS0ke2hlYWRlckluZGV4fWB9IHZhbHVlPXtoZWFkZXJ9PntoZWFkZXJ9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkNvbG9ubmUgRGVzdGluYXRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXBwaW5nLmRlc3RpbmF0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVNYXBwaW5nKGluZGV4LCAnZGVzdGluYXRpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wdXJwbGUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlPDqWxlY3Rpb25uZXIgdW5lIGNvbG9ubmUgZGVzdGluYXRpb248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtkZXN0aW5hdGlvbkZpbGUuaGVhZGVycy5tYXAoKGhlYWRlciwgaGVhZGVySW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2BkZXN0LSR7aGVhZGVySW5kZXh9YH0gdmFsdWU9e2hlYWRlcn0+e2hlYWRlcn08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+VHJhbnNmb3JtYXRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXBwaW5nLnRyYW5zZm9ybWF0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVNYXBwaW5nKGluZGV4LCAndHJhbnNmb3JtYXRpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wdXJwbGUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm5vbmVcIj5BdWN1bmU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ1cHBlcmNhc2VcIj5NQUpVU0NVTEVTPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibG93ZXJjYXNlXCI+bWludXNjdWxlczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInJlcGxhY2VcIj5SZW1wbGFjZXIgZHUgdGV4dGU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtYW51YWxcIj5WYWxldXIgbWFudWVsbGU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFLDqGdsZXMgZGUgcmVtcGxhY2VtZW50ICovfVxuICAgICAgICAgICAgICAgICAge21hcHBpbmcudHJhbnNmb3JtYXRpb24gPT09ICdyZXBsYWNlJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTQgYmctYmx1ZS01MCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtYmx1ZS04MDBcIj5Sw6hnbGVzIGRlIHJlbXBsYWNlbWVudDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZFJlcGxhY2VSdWxlKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZCB0ZXh0LXNtIGhvdmVyOmJnLWJsdWUtNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKyBBam91dGVyIHLDqGdsZVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAge21hcHBpbmcucmVwbGFjZVJ1bGVzPy5tYXAoKHJ1bGUsIHJ1bGVJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2BydWxlLSR7cnVsZUluZGV4fWB9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2kgY29udGllbnQuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtydWxlLmZyb219XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVSZXBsYWNlUnVsZShpbmRleCwgcnVsZUluZGV4LCAnZnJvbScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlbXBsYWNlciBwYXIuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtydWxlLnRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlUmVwbGFjZVJ1bGUoaW5kZXgsIHJ1bGVJbmRleCwgJ3RvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZVJlcGxhY2VSdWxlKGluZGV4LCBydWxlSW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJlZC02MDAgaG92ZXI6YmctcmVkLTUwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7LyogVmFsZXVyIG1hbnVlbGxlICovfVxuICAgICAgICAgICAgICAgICAge21hcHBpbmcudHJhbnNmb3JtYXRpb24gPT09ICdtYW51YWwnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+VmFsZXVyIMOgIGluc8OpcmVyPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVGFwZXogbGEgdmFsZXVyIMOgIGluc8OpcmVyIGRhbnMgdG91dGVzIGxlcyBsaWduZXMuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcHBpbmcubWFudWFsVmFsdWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZU1hcHBpbmcoaW5kZXgsICdtYW51YWxWYWx1ZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXB1cnBsZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtdC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVNYXBwaW5nKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTIgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgU3VwcHJpbWVyIGNlIG1hcHBpbmdcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAge21hcHBpbmdzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctMTIgaC0xMiBteC1hdXRvIG1iLTQgdGV4dC1ncmF5LTMwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8cD5BdWN1biBtYXBwaW5nIGTDqWZpbmkuIENsaXF1ZXogc3VyIFwiQWpvdXRlciBNYXBwaW5nXCIgcG91ciBjb21tZW5jZXIuPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBQcsOpdmlzdWFsaXNhdGlvbiAqL31cbiAgICAgICAgICAgIHtwcmV2aWV3RGF0YS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHAtNiBiZy1ibHVlLTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTgwMCBtYi00XCI+UHLDqXZpc3VhbGlzYXRpb24gKDUgcHJlbWnDqHJlcyBsaWduZXMpPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtkZXN0aW5hdGlvbkZpbGUuaGVhZGVycy5tYXAoKGhlYWRlciwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17YHByZXZpZXctaGVhZGVyLSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwicC0yIHRleHQtbGVmdCB0ZXh0LWJsdWUtODAwIGZvbnQtbWVkaXVtIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aGVhZGVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgIHtwcmV2aWV3RGF0YS5tYXAoKHJvdywgcm93SW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2BwcmV2aWV3LXJvdy0ke3Jvd0luZGV4fWB9IGNsYXNzTmFtZT1cImJnLXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtyb3cubWFwKChjZWxsLCBjZWxsSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQga2V5PXtgcHJldmlldy1jZWxsLSR7cm93SW5kZXh9LSR7Y2VsbEluZGV4fWB9IGNsYXNzTmFtZT1cInAtMiBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjZWxsIHx8ICctJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7bWFwcGluZ3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2V4cG9ydERhdGF9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC04IHB5LTQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWN5YW4tNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWN5YW4tNzAwIHRyYW5zaXRpb24tYWxsIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgc2hhZG93LWxnIHRleHQtbGcgZm9udC1zZW1pYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAnRXhwb3J0IGVuIGNvdXJzLi4uJyA6ICdFeHBvcnRlciBsZXMgRG9ubsOpZXMnfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIE1vZGFsIGRlIHNhdXZlZ2FyZGUgZGUgbWFwcGluZyAqL31cbiAgICAgICAge3Nob3dTYXZlTWFwcGluZ01vZGFsICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTUwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHAtOCBtYXgtdy1tZCB3LWZ1bGwgbXgtNFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+U2F1dmVnYXJkZXIgbGEgY29uZmlndXJhdGlvbjwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgTm9tIGRlIGxhIGNvbmZpZ3VyYXRpb25cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcHBpbmdOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXBwaW5nTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBNYXBwaW5nIGNsaWVudHMgdmVycyBjb21tYW5kZXNcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1NhdmVNYXBwaW5nTW9kYWwoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBzZXRNYXBwaW5nTmFtZSgnJyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMiBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEFubnVsZXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzYXZlTWFwcGluZ0NvbmZpZ3VyYXRpb259XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBweS0yIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JlZW4tNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBTYXV2ZWdhcmRlclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBIaXN0b3J5IFNlY3Rpb24gKi99XG4gICAgICAgIHtoaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXhsIHAtOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGFuaW1hdGUtc2xpZGUtdXBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxIaXN0b3J5IGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1ncmVlbi02MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPkhpc3RvcmlxdWUgZGVzIFRyYW5zZmVydHM8L2gyPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NsZWFySGlzdG9yeX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1yZWQtMjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgRWZmYWNlciBsJ2hpc3RvcmlxdWVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAge2hpc3RvcnkubWFwKChlbnRyeSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17YGhpc3RvcnktJHtpbmRleH0tJHtlbnRyeS50aW1lc3RhbXAuZ2V0VGltZSgpfWB9IGNsYXNzTmFtZT1cInAtNCBiZy1ncmVlbi01MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICDwn5OKIHtlbnRyeS5zb3VyY2VGaWxlfSDihpIge2VudHJ5LmRlc3RpbmF0aW9uRmlsZX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2VudHJ5LnRpbWVzdGFtcC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmVlbi03MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICB7ZW50cnkucm93c1Byb2Nlc3NlZH0gbGlnbmVzIHRyYWl0w6llcyDigKIge2VudHJ5LnRvdGFsUm93c30gbGlnbmVzIGF1IHRvdGFsIOKAoiBTYXV2ZWdhcmTDqSBkYW5zIFN1cGFiYXNlXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIHtlbnRyeS5tYXBwaW5ncy5tYXAoKG1hcHBpbmcsIG1hcHBpbmdJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YG1hcHBpbmctJHttYXBwaW5nSW5kZXh9YH0gY2xhc3NOYW1lPVwicHgtMiBweS0xIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCByb3VuZGVkIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttYXBwaW5nLnNvdXJjZX0g4oaSIHttYXBwaW5nLmRlc3RpbmF0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdLCJmaWxlIjoiL2hvbWUvcHJvamVjdC9zcmMvQXBwLnRzeCJ9