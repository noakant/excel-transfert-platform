import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Auth.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3d9a1eec"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/project/src/components/Auth.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3d9a1eec"; const useState = __vite__cjsImport3_react["useState"];
import { supabase } from "/src/lib/supabase.ts";
import { LogIn, Mail, Lock } from "/node_modules/lucide-react/dist/esm/lucide-react.js?v=56689416";
const Auth = ({ onAuthSuccess }) => {
  _s();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (error) throw error;
        setMessage("Connexion réussie !");
        onAuthSuccess();
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password
        });
        if (error) throw error;
        setMessage("Compte créé avec succès ! Vous pouvez maintenant vous connecter.");
        setIsLogin(true);
      }
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-8 w-full max-w-md border border-gray-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxDEV(LogIn, { className: "w-10 h-10 text-blue-600" }, void 0, false, {
          fileName: "/home/project/src/components/Auth.tsx",
          lineNumber: 51,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent", children: "Connexion Requise" }, void 0, false, {
          fileName: "/home/project/src/components/Auth.tsx",
          lineNumber: 52,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/project/src/components/Auth.tsx",
        lineNumber: 50,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Connectez-vous pour accéder à la plateforme de transfert Excel" }, void 0, false, {
        fileName: "/home/project/src/components/Auth.tsx",
        lineNumber: 56,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/project/src/components/Auth.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAuth, className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
          /* @__PURE__ */ jsxDEV(Mail, { className: "w-4 h-4 inline mr-2" }, void 0, false, {
            fileName: "/home/project/src/components/Auth.tsx",
            lineNumber: 64,
            columnNumber: 15
          }, this),
          "Email"
        ] }, void 0, true, {
          fileName: "/home/project/src/components/Auth.tsx",
          lineNumber: 63,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "email",
            value: email,
            onChange: (e) => setEmail(e.target.value),
            required: true,
            className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
            placeholder: "votre@email.com"
          },
          void 0,
          false,
          {
            fileName: "/home/project/src/components/Auth.tsx",
            lineNumber: 67,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/project/src/components/Auth.tsx",
        lineNumber: 62,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "w-4 h-4 inline mr-2" }, void 0, false, {
            fileName: "/home/project/src/components/Auth.tsx",
            lineNumber: 79,
            columnNumber: 15
          }, this),
          "Mot de passe"
        ] }, void 0, true, {
          fileName: "/home/project/src/components/Auth.tsx",
          lineNumber: 78,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "password",
            value: password,
            onChange: (e) => setPassword(e.target.value),
            required: true,
            className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
            placeholder: "••••••••"
          },
          void 0,
          false,
          {
            fileName: "/home/project/src/components/Auth.tsx",
            lineNumber: 82,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/project/src/components/Auth.tsx",
        lineNumber: 77,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          disabled: loading,
          className: "w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all disabled:opacity-50 font-semibold",
          children: loading ? "Chargement..." : isLogin ? "Se connecter" : "Créer un compte"
        },
        void 0,
        false,
        {
          fileName: "/home/project/src/components/Auth.tsx",
          lineNumber: 92,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/project/src/components/Auth.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 text-center", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setIsLogin(!isLogin),
        className: "text-blue-600 hover:text-blue-700 font-medium",
        children: isLogin ? "Pas de compte ? Créer un compte" : "Déjà un compte ? Se connecter"
      },
      void 0,
      false,
      {
        fileName: "/home/project/src/components/Auth.tsx",
        lineNumber: 102,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/home/project/src/components/Auth.tsx",
      lineNumber: 101,
      columnNumber: 9
    }, this),
    message && /* @__PURE__ */ jsxDEV("div", { className: `mt-4 p-3 rounded-lg text-sm ${message.includes("succès") || message.includes("réussie") ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`, children: message }, void 0, false, {
      fileName: "/home/project/src/components/Auth.tsx",
      lineNumber: 111,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/project/src/components/Auth.tsx",
    lineNumber: 48,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/project/src/components/Auth.tsx",
    lineNumber: 47,
    columnNumber: 5
  }, this);
};
_s(Auth, "PztPNNaUG088C4csv7z38KRMUj0=");
_c = Auth;
export default Auth;
var _c;
$RefreshReg$(_c, "Auth");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/project/src/components/Auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/project/src/components/Auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RZOzJCQWxEWjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFpQkMsTUFBTUMsWUFBWTtBQU01QyxNQUFNQyxPQUE0QkEsQ0FBQyxFQUFFQyxjQUFjLE1BQU07QUFBQUMsS0FBQTtBQUN2RCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVQsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ1UsT0FBT0MsUUFBUSxJQUFJWCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDWSxVQUFVQyxXQUFXLElBQUliLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNjLFNBQVNDLFVBQVUsSUFBSWYsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2dCLFNBQVNDLFVBQVUsSUFBSWpCLFNBQVMsRUFBRTtBQUV6QyxRQUFNa0IsYUFBYSxPQUFPQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQkwsZUFBVyxJQUFJO0FBQ2ZFLGVBQVcsRUFBRTtBQUViLFFBQUk7QUFDRixVQUFJVCxTQUFTO0FBQ1gsY0FBTSxFQUFFYSxNQUFNLElBQUksTUFBTXBCLFNBQVNxQixLQUFLQyxtQkFBbUI7QUFBQSxVQUN2RGI7QUFBQUEsVUFDQUU7QUFBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSVMsTUFBTyxPQUFNQTtBQUNqQkosbUJBQVcscUJBQXFCO0FBQ2hDWCxzQkFBYztBQUFBLE1BQ2hCLE9BQU87QUFDTCxjQUFNLEVBQUVlLE1BQU0sSUFBSSxNQUFNcEIsU0FBU3FCLEtBQUtFLE9BQU87QUFBQSxVQUMzQ2Q7QUFBQUEsVUFDQUU7QUFBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSVMsTUFBTyxPQUFNQTtBQUNqQkosbUJBQVcsa0VBQWtFO0FBQzdFUixtQkFBVyxJQUFJO0FBQUEsTUFDakI7QUFBQSxJQUNGLFNBQVNZLE9BQVk7QUFDbkJKLGlCQUFXSSxNQUFNTCxPQUFPO0FBQUEsSUFDMUIsVUFBQztBQUNDRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUseUdBQ2IsaUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsK0JBQUMsU0FBTSxXQUFVLDZCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsUUFDMUMsdUJBQUMsUUFBRyxXQUFVLCtGQUE2RixpQ0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxpQkFBZSw4RUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVUcsWUFBWSxXQUFVLGFBQ3BDO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLGlDQUFDLFFBQUssV0FBVSx5QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQTtBQUFBLGFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9SO0FBQUFBLFlBQ1AsVUFBVSxDQUFDUyxNQUFNUixTQUFTUSxFQUFFTSxPQUFPQyxLQUFLO0FBQUEsWUFDeEM7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTStCO0FBQUEsV0FYakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEsaUNBQUMsUUFBSyxXQUFVLHlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT2Q7QUFBQUEsWUFDUCxVQUFVLENBQUNPLE1BQU1OLFlBQVlNLEVBQUVNLE9BQU9DLEtBQUs7QUFBQSxZQUMzQztBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBO0FBQUEsVUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNd0I7QUFBQSxXQVgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxVQUFVWjtBQUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVUQSxvQkFBVSxrQkFBa0JOLFVBQVUsaUJBQWlCO0FBQUE7QUFBQSxRQUwxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUyxNQUFNQyxXQUFXLENBQUNELE9BQU87QUFBQSxRQUNsQyxXQUFVO0FBQUEsUUFFVEEsb0JBQVUsb0NBQW9DO0FBQUE7QUFBQSxNQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUNRLFdBQ0MsdUJBQUMsU0FBSSxXQUFXLCtCQUNkQSxRQUFRVyxTQUFTLFFBQVEsS0FBS1gsUUFBUVcsU0FBUyxTQUFTLElBQ3BELGdDQUNBLHlCQUF5QixJQUU1QlgscUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsT0FyRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVFQSxLQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUVBO0FBRUo7QUFBRVQsR0FqSElGLE1BQXlCO0FBQUF1QixLQUF6QnZCO0FBbUhOLGVBQWVBO0FBQUssSUFBQXVCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInN1cGFiYXNlIiwiTG9nSW4iLCJNYWlsIiwiTG9jayIsIkF1dGgiLCJvbkF1dGhTdWNjZXNzIiwiX3MiLCJpc0xvZ2luIiwic2V0SXNMb2dpbiIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwibG9hZGluZyIsInNldExvYWRpbmciLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsImhhbmRsZUF1dGgiLCJlIiwicHJldmVudERlZmF1bHQiLCJlcnJvciIsImF1dGgiLCJzaWduSW5XaXRoUGFzc3dvcmQiLCJzaWduVXAiLCJ0YXJnZXQiLCJ2YWx1ZSIsImluY2x1ZGVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tICcuLi9saWIvc3VwYWJhc2UnO1xuaW1wb3J0IHsgTG9nSW4sIFVzZXJQbHVzLCBNYWlsLCBMb2NrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIEF1dGhQcm9wcyB7XG4gIG9uQXV0aFN1Y2Nlc3M6ICgpID0+IHZvaWQ7XG59XG5cbmNvbnN0IEF1dGg6IFJlYWN0LkZDPEF1dGhQcm9wcz4gPSAoeyBvbkF1dGhTdWNjZXNzIH0pID0+IHtcbiAgY29uc3QgW2lzTG9naW4sIHNldElzTG9naW5dID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlQXV0aCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBzZXRNZXNzYWdlKCcnKTtcblxuICAgIHRyeSB7XG4gICAgICBpZiAoaXNMb2dpbikge1xuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7XG4gICAgICAgICAgZW1haWwsXG4gICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xuICAgICAgICBzZXRNZXNzYWdlKCdDb25uZXhpb24gcsOpdXNzaWUgIScpO1xuICAgICAgICBvbkF1dGhTdWNjZXNzKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcCh7XG4gICAgICAgICAgZW1haWwsXG4gICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xuICAgICAgICBzZXRNZXNzYWdlKCdDb21wdGUgY3LDqcOpIGF2ZWMgc3VjY8OocyAhIFZvdXMgcG91dmV6IG1haW50ZW5hbnQgdm91cyBjb25uZWN0ZXIuJyk7XG4gICAgICAgIHNldElzTG9naW4odHJ1ZSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHZpYS13aGl0ZSB0by1jeWFuLTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3cteGwgcC04IHctZnVsbCBtYXgtdy1tZCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgbWItNFwiPlxuICAgICAgICAgICAgPExvZ0luIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWJsdWUtNjAwXCIgLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWN5YW4tNjAwIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XG4gICAgICAgICAgICAgIENvbm5leGlvbiBSZXF1aXNlXG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5cbiAgICAgICAgICAgIENvbm5lY3Rlei12b3VzIHBvdXIgYWNjw6lkZXIgw6AgbGEgcGxhdGVmb3JtZSBkZSB0cmFuc2ZlcnQgRXhjZWxcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBdXRofSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XG4gICAgICAgICAgICAgIDxNYWlsIGNsYXNzTmFtZT1cInctNCBoLTQgaW5saW5lIG1yLTJcIiAvPlxuICAgICAgICAgICAgICBFbWFpbFxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInZvdHJlQGVtYWlsLmNvbVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxuICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IGlubGluZSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgTW90IGRlIHBhc3NlXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1jeWFuLTYwMCB0ZXh0LXdoaXRlIHB5LTMgcm91bmRlZC1sZyBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWN5YW4tNzAwIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNTAgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2xvYWRpbmcgPyAnQ2hhcmdlbWVudC4uLicgOiBpc0xvZ2luID8gJ1NlIGNvbm5lY3RlcicgOiAnQ3LDqWVyIHVuIGNvbXB0ZSd9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0xvZ2luKCFpc0xvZ2luKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTcwMCBmb250LW1lZGl1bVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2lzTG9naW4gPyAnUGFzIGRlIGNvbXB0ZSA/IENyw6llciB1biBjb21wdGUnIDogJ0TDqWrDoCB1biBjb21wdGUgPyBTZSBjb25uZWN0ZXInfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7bWVzc2FnZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtdC00IHAtMyByb3VuZGVkLWxnIHRleHQtc20gJHtcbiAgICAgICAgICAgIG1lc3NhZ2UuaW5jbHVkZXMoJ3N1Y2PDqHMnKSB8fCBtZXNzYWdlLmluY2x1ZGVzKCdyw6l1c3NpZScpIFxuICAgICAgICAgICAgICA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAnIFxuICAgICAgICAgICAgICA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCdcbiAgICAgICAgICB9YH0+XG4gICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXV0aDsiXSwiZmlsZSI6Ii9ob21lL3Byb2plY3Qvc3JjL2NvbXBvbmVudHMvQXV0aC50c3gifQ==